import { pgTable, serial, text, timestamp, integer, boolean } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  avatar: text("avatar").notNull(),
  role: text("role").notNull(),
  department: text("department").notNull(),
  status: text("status").notNull().default("online"), // online, busy, away, offline
  statusMessage: text("status_message").default(""),
  bio: text("bio").default(""),
  reputation: integer("reputation").default(100),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const conversations = pgTable("conversations", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  type: text("type").notNull().default("direct"), // direct, room, project
  user1Id: text("user1_id").notNull(),
  user2Id: text("user2_id").notNull(),
  description: text("description").default(""),
  isPinned: boolean("is_pinned").default(false),
  lastMessageText: text("last_message_text").default(""),
  lastMessageAt: timestamp("last_message_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: text("conversation_id").notNull(),
  senderId: text("sender_id").notNull(),
  receiverId: text("receiver_id").notNull(),
  content: text("content").default(""),
  type: text("type").notNull().default("text"), // text, image, document, voice, code, call_log
  mediaUrl: text("media_url"),
  mediaName: text("media_name"),
  mediaSize: integer("media_size"), // in bytes
  mediaMime: text("media_mime"),
  mediaDuration: integer("media_duration"), // in seconds for voice notes
  mediaWaveform: text("media_waveform"), // JSON array of numbers or waveform representation
  replyToId: integer("reply_to_id"),
  isEdited: boolean("is_edited").default(false),
  isPinned: boolean("is_pinned").default(false),
  reactions: text("reactions").default("{}"), // JSON string: {"👍": ["user_1"], "❤️": ["user_2"]}
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sharedFiles = pgTable("shared_files", {
  id: serial("id").primaryKey(),
  senderId: text("sender_id").notNull(),
  conversationId: text("conversation_id"),
  category: text("category").notNull(), // document, image, voice, code, other
  fileName: text("file_name").notNull(),
  fileUrl: text("file_url").notNull(),
  fileSize: integer("file_size").notNull(),
  mimeType: text("mime_type").notNull(),
  description: text("description").default(""),
  tags: text("tags").default("[]"), // JSON string array
  downloadsCount: integer("downloads_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const qnaQuestions = pgTable("qna_questions", {
  id: serial("id").primaryKey(),
  authorId: text("author_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull().default("General"),
  tags: text("tags").default("[]"), // JSON array string
  viewsCount: integer("views_count").default(0),
  upvotesCount: integer("upvotes_count").default(0),
  isSolved: boolean("is_solved").default(false),
  acceptedAnswerId: integer("accepted_answer_id"),
  attachments: text("attachments").default("[]"), // JSON array of file items
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const qnaAnswers = pgTable("qna_answers", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id").notNull(),
  authorId: text("author_id").notNull(),
  content: text("content").notNull(),
  upvotesCount: integer("upvotes_count").default(0),
  isAccepted: boolean("is_accepted").default(false),
  attachments: text("attachments").default("[]"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const qnaVotes = pgTable("qna_votes", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  targetType: text("target_type").notNull(), // question, answer
  targetId: integer("target_id").notNull(),
  voteType: integer("vote_type").notNull(), // 1 for upvote, -1 for downvote
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const forums = pgTable("forums", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull().default("message-square"),
  color: text("color").notNull().default("indigo"),
  createdById: text("created_by_id").notNull(),
  threadsCount: integer("threads_count").default(0),
  isPrivate: boolean("is_private").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const forumThreads = pgTable("forum_threads", {
  id: serial("id").primaryKey(),
  forumId: integer("forum_id").notNull(),
  authorId: text("author_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  tags: text("tags").default("[]"),
  isPinned: boolean("is_pinned").default(false),
  isLocked: boolean("is_locked").default(false),
  viewsCount: integer("views_count").default(0),
  likesCount: integer("likes_count").default(0),
  repliesCount: integer("replies_count").default(0),
  hasPoll: boolean("has_poll").default(false),
  pollData: text("poll_data"), // JSON: { question: string, options: [{ id: number, text: string, votes: string[] }] }
  attachments: text("attachments").default("[]"),
  lastActivityAt: timestamp("last_activity_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const forumReplies = pgTable("forum_replies", {
  id: serial("id").primaryKey(),
  threadId: integer("thread_id").notNull(),
  authorId: text("author_id").notNull(),
  replyToId: integer("reply_to_id"),
  content: text("content").notNull(),
  likesCount: integer("likes_count").default(0),
  attachments: text("attachments").default("[]"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const forumLikes = pgTable("forum_likes", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  targetType: text("target_type").notNull(), // thread, reply
  targetId: integer("target_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const collaborationNotes = pgTable("collaboration_notes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default("Shared Scratchpad & Quick Ideas"),
  content: text("content").notNull().default(""),
  updatedById: text("updated_by_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
