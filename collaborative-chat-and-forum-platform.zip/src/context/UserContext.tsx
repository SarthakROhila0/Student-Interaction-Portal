"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import { User } from "@/types";
import confetti from "canvas-confetti";

interface UserContextType {
  users: User[];
  currentUser: User | null;
  partnerUser: User | null;
  setCurrentUser: (user: User) => void;
  switchPersona: (userId: string) => void;
  splitScreenMode: boolean;
  setSplitScreenMode: (enabled: boolean) => void;
  activeTab: "chat" | "vault" | "qna" | "forums" | "scratchpad";
  setActiveTab: (tab: "chat" | "vault" | "qna" | "forums" | "scratchpad") => void;
  isLoading: boolean;
  refreshUsers: () => Promise<void>;
  triggerCelebration: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [partnerUser, setPartnerUser] = useState<User | null>(null);
  const [splitScreenMode, setSplitScreenMode] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<"chat" | "vault" | "qna" | "forums" | "scratchpad">("chat");
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchUsers = async () => {
    try {
      const res = await fetch("/api/users");
      const data = await res.json();
      if (data.success && Array.isArray(data.users) && data.users.length > 0) {
        setUsers(data.users);

        // Default: Alex Rivera as currentUser, Elena Chen as partnerUser
        const alex = data.users.find((u: User) => u.id === "user_alex") || data.users[0];
        const elena = data.users.find((u: User) => u.id === "user_elena") || data.users[1] || data.users[0];

        setCurrentUser((prev) => prev || alex);
        setPartnerUser((prev) => prev || elena);
      }
    } catch (err) {
      console.error("Failed to load users:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const switchPersona = (userId: string) => {
    const selected = users.find((u) => u.id === userId);
    if (selected) {
      // If current is changed, set previous as partner
      if (currentUser && currentUser.id !== userId) {
        setPartnerUser(currentUser);
      }
      setCurrentUser(selected);
    }
  };

  const triggerCelebration = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ["#6366f1", "#a855f7", "#ec4899", "#10b981", "#f59e0b"],
      });
    } catch (e) {
      // Confetti fallback
    }
  };

  return (
    <UserContext.Provider
      value={{
        users,
        currentUser,
        partnerUser,
        setCurrentUser,
        switchPersona,
        splitScreenMode,
        setSplitScreenMode,
        activeTab,
        setActiveTab,
        isLoading,
        refreshUsers: fetchUsers,
        triggerCelebration,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
}
