import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  conversations,
  messages,
  sharedFiles,
  qnaQuestions,
  qnaAnswers,
  qnaVotes,
  forums,
  forumThreads,
  forumReplies,
  forumLikes,
  collaborationNotes,
} from "@/db/schema";
import { ensureDatabaseSeeded } from "@/lib/seed";

export async function POST() {
  try {
    // Delete existing records
    await db.delete(forumLikes);
    await db.delete(forumReplies);
    await db.delete(forumThreads);
    await db.delete(forums);
    await db.delete(qnaVotes);
    await db.delete(qnaAnswers);
    await db.delete(qnaQuestions);
    await db.delete(sharedFiles);
    await db.delete(messages);
    await db.delete(conversations);
    await db.delete(collaborationNotes);
    await db.delete(users);

    // Re-seed
    await ensureDatabaseSeeded();

    return NextResponse.json({ success: true, message: "Database reset and re-seeded successfully!" });
  } catch (error: any) {
    console.error("Reset error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
