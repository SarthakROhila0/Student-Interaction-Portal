import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const contentType = request.headers.get("content-type") || "";

    if (contentType.includes("application/json")) {
      const body = await request.json();
      const { dataUrl, fileName, mimeType, size } = body;

      if (!dataUrl) {
        return NextResponse.json({ success: false, error: "dataUrl is required" }, { status: 400 });
      }

      // Determine category
      let category = "document";
      if (mimeType?.startsWith("image/")) category = "image";
      else if (mimeType?.startsWith("audio/")) category = "voice";
      else if (
        fileName?.endsWith(".ts") ||
        fileName?.endsWith(".tsx") ||
        fileName?.endsWith(".js") ||
        fileName?.endsWith(".json") ||
        fileName?.endsWith(".sql")
      ) {
        category = "code";
      }

      return NextResponse.json({
        success: true,
        fileUrl: dataUrl,
        fileName: fileName || `file-${Date.now()}`,
        fileSize: size || Math.round(dataUrl.length * 0.75),
        mimeType: mimeType || "application/octet-stream",
        category,
      });
    }

    // Handle multipart form data
    const formData = await request.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ success: false, error: "No file provided" }, { status: 400 });
    }

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const base64 = buffer.toString("base64");
    const mimeType = file.type || "application/octet-stream";
    const dataUrl = `data:${mimeType};base64,${base64}`;

    let category = "document";
    if (mimeType.startsWith("image/")) category = "image";
    else if (mimeType.startsWith("audio/")) category = "voice";
    else if (
      file.name.endsWith(".ts") ||
      file.name.endsWith(".tsx") ||
      file.name.endsWith(".js") ||
      file.name.endsWith(".json") ||
      file.name.endsWith(".sql")
    ) {
      category = "code";
    }

    return NextResponse.json({
      success: true,
      fileUrl: dataUrl,
      fileName: file.name,
      fileSize: file.size,
      mimeType,
      category,
    });
  } catch (error: any) {
    console.error("Upload error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
