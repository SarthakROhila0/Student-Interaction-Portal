import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { status, statusMessage, bio, role, department } = body;

    const updated = await db
      .update(users)
      .set({
        ...(status ? { status } : {}),
        ...(statusMessage !== undefined ? { statusMessage } : {}),
        ...(bio !== undefined ? { bio } : {}),
        ...(role ? { role } : {}),
        ...(department ? { department } : {}),
      })
      .where(eq(users.id, id))
      .returning();

    if (updated.length === 0) {
      return NextResponse.json({ success: false, error: "User not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, user: updated[0] });
  } catch (error: any) {
    console.error("Update user error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
