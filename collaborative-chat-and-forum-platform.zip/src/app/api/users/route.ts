import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/lib/seed";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureDatabaseSeeded();
    const allUsers = await db.select().from(users).orderBy(desc(users.reputation));
    return NextResponse.json({ success: true, users: allUsers });
  } catch (error: any) {
    console.error("Bootstrap error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, role, department, avatar, bio } = body;

    if (!name) {
      return NextResponse.json({ success: false, error: "Name is required" }, { status: 400 });
    }

    const newId = `user_${Date.now()}`;
    const newUser = await db
      .insert(users)
      .values({
        id: newId,
        name,
        email: `${name.toLowerCase().replace(/\s+/g, ".")}@portal.dev`,
        avatar: avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`,
        role: role || "Contributor",
        department: department || "General",
        status: "online",
        statusMessage: "Active in portal",
        bio: bio || "Collaborating on engineering, design, Q&A, and community forums.",
        reputation: 100,
      })
      .returning();

    return NextResponse.json({ success: true, user: newUser[0] });
  } catch (error: any) {
    console.error("Create user error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
