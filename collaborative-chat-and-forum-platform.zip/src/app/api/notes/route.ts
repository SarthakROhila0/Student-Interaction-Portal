import { NextResponse } from "next/server";
import { db } from "@/db";
import { collaborationNotes, users } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/lib/seed";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureDatabaseSeeded();
    const notes = await db.select().from(collaborationNotes).orderBy(desc(collaborationNotes.updatedAt));
    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map((u) => [u.id, u]));

    const note = notes[0] || null;
    return NextResponse.json({
      success: true,
      note: note
        ? {
            ...note,
            updatedBy: userMap.get(note.updatedById) || null,
          }
        : null,
    });
  } catch (error: any) {
    console.error("Fetch notes error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { title, content, updatedById } = body;

    const existing = await db.select().from(collaborationNotes);
    let note;
    if (existing.length === 0) {
      const inserted = await db
        .insert(collaborationNotes)
        .values({
          title: title || "Sprint Collaboration & Shared Scratchpad",
          content: content || "",
          updatedById: updatedById || "user_alex",
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();
      note = inserted[0];
    } else {
      const updated = await db
        .update(collaborationNotes)
        .set({
          title: title !== undefined ? title : existing[0].title,
          content: content !== undefined ? content : existing[0].content,
          updatedById: updatedById || existing[0].updatedById,
          updatedAt: new Date(),
        })
        .where(eq(collaborationNotes.id, existing[0].id))
        .returning();
      note = updated[0];
    }

    return NextResponse.json({ success: true, note });
  } catch (error: any) {
    console.error("Update notes error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
