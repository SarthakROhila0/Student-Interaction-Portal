import { NextResponse } from "next/server";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const messageId = parseInt(id, 10);
    if (isNaN(messageId)) {
      return NextResponse.json({ success: false, error: "Invalid message ID" }, { status: 400 });
    }

    const body = await request.json();
    const { action, emoji, userId, content, isPinned } = body;

    const existing = await db.select().from(messages).where(eq(messages.id, messageId));
    if (existing.length === 0) {
      return NextResponse.json({ success: false, error: "Message not found" }, { status: 404 });
    }

    const msg = existing[0];

    // Handle reaction toggle
    if (action === "toggle_reaction" && emoji && userId) {
      let reactions: Record<string, string[]> = {};
      try {
        reactions = msg.reactions ? JSON.parse(msg.reactions) : {};
      } catch (e) {
        reactions = {};
      }

      if (!reactions[emoji]) {
        reactions[emoji] = [];
      }

      if (reactions[emoji].includes(userId)) {
        reactions[emoji] = reactions[emoji].filter((uid) => uid !== userId);
        if (reactions[emoji].length === 0) {
          delete reactions[emoji];
        }
      } else {
        reactions[emoji].push(userId);
      }

      const updated = await db
        .update(messages)
        .set({ reactions: JSON.stringify(reactions) })
        .where(eq(messages.id, messageId))
        .returning();

      return NextResponse.json({
        success: true,
        message: {
          ...updated[0],
          reactions,
        },
      });
    }

    // Handle pin toggle
    if (action === "toggle_pin" || isPinned !== undefined) {
      const newPinState = isPinned !== undefined ? isPinned : !msg.isPinned;
      const updated = await db
        .update(messages)
        .set({ isPinned: newPinState })
        .where(eq(messages.id, messageId))
        .returning();

      return NextResponse.json({ success: true, message: updated[0] });
    }

    // Handle edit content
    if (action === "edit" && content !== undefined) {
      const updated = await db
        .update(messages)
        .set({ content, isEdited: true })
        .where(eq(messages.id, messageId))
        .returning();

      return NextResponse.json({ success: true, message: updated[0] });
    }

    return NextResponse.json({ success: false, error: "Unsupported action" }, { status: 400 });
  } catch (error: any) {
    console.error("Patch message error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const messageId = parseInt(id, 10);
    if (isNaN(messageId)) {
      return NextResponse.json({ success: false, error: "Invalid message ID" }, { status: 400 });
    }

    await db.delete(messages).where(eq(messages.id, messageId));
    return NextResponse.json({ success: true, deletedId: messageId });
  } catch (error: any) {
    console.error("Delete message error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
