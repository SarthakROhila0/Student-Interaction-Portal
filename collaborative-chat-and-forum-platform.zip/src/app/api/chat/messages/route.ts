import { NextResponse } from "next/server";
import { db } from "@/db";
import { messages, conversations, sharedFiles, users } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const conversationId = searchParams.get("conversationId") || "conv_alex_elena";

    const messageList = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(asc(messages.createdAt));

    // Get user map for author details
    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map((u) => [u.id, u]));

    const populatedMessages = messageList.map((m) => {
      let parsedReactions = {};
      try {
        parsedReactions = m.reactions ? JSON.parse(m.reactions) : {};
      } catch (e) {
        parsedReactions = {};
      }

      let parsedWaveform = [];
      try {
        parsedWaveform = m.mediaWaveform ? JSON.parse(m.mediaWaveform) : [];
      } catch (e) {
        parsedWaveform = [];
      }

      return {
        ...m,
        sender: userMap.get(m.senderId) || null,
        receiver: userMap.get(m.receiverId) || null,
        reactions: parsedReactions,
        mediaWaveform: parsedWaveform,
      };
    });

    return NextResponse.json({ success: true, messages: populatedMessages });
  } catch (error: any) {
    console.error("Fetch messages error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      conversationId = "conv_alex_elena",
      senderId,
      receiverId,
      content = "",
      type = "text",
      mediaUrl,
      mediaName,
      mediaSize,
      mediaMime,
      mediaDuration,
      mediaWaveform,
      replyToId,
    } = body;

    if (!senderId || !receiverId) {
      return NextResponse.json({ success: false, error: "Sender and receiver IDs are required" }, { status: 400 });
    }

    // Insert new message
    const insertedMessage = await db
      .insert(messages)
      .values({
        conversationId,
        senderId,
        receiverId,
        content: content || "",
        type,
        mediaUrl: mediaUrl || null,
        mediaName: mediaName || null,
        mediaSize: mediaSize ? Number(mediaSize) : null,
        mediaMime: mediaMime || null,
        mediaDuration: mediaDuration ? Number(mediaDuration) : null,
        mediaWaveform: mediaWaveform ? (typeof mediaWaveform === "string" ? mediaWaveform : JSON.stringify(mediaWaveform)) : null,
        replyToId: replyToId ? Number(replyToId) : null,
        reactions: "{}",
        createdAt: new Date(),
      })
      .returning();

    const newMsg = insertedMessage[0];

    // Determine summary text for conversation
    let lastSummary = content;
    if (type === "image") lastSummary = "📷 Shared an image: " + (mediaName || "Image");
    else if (type === "document") lastSummary = "📄 Shared a document: " + (mediaName || "Document");
    else if (type === "voice") lastSummary = "🎤 Sent a voice note (" + (mediaDuration ? `${mediaDuration}s` : "audio") + ")";
    else if (type === "code") lastSummary = "💻 Shared a code snippet";

    // Update conversation lastMessageAt and lastMessageText
    await db
      .update(conversations)
      .set({
        lastMessageText: lastSummary || "New message",
        lastMessageAt: new Date(),
      })
      .where(eq(conversations.id, conversationId));

    // If media file (document, image, voice), auto-index into shared_files vault
    if (mediaUrl && (type === "document" || type === "image" || type === "voice")) {
      const category = type === "document" ? "document" : type === "image" ? "image" : "voice";
      await db.insert(sharedFiles).values({
        senderId,
        conversationId,
        category,
        fileName: mediaName || `${category}-${Date.now()}`,
        fileUrl: mediaUrl,
        fileSize: mediaSize ? Number(mediaSize) : 1024 * 100,
        mimeType: mediaMime || (category === "image" ? "image/jpeg" : category === "voice" ? "audio/webm" : "application/pdf"),
        description: content || `Uploaded ${category} via direct chat`,
        tags: JSON.stringify(["Chat Upload", category.toUpperCase()]),
        createdAt: new Date(),
      });
    }

    // Fetch sender info
    const sender = await db.select().from(users).where(eq(users.id, senderId));

    return NextResponse.json({
      success: true,
      message: {
        ...newMsg,
        sender: sender[0] || null,
        reactions: {},
        mediaWaveform: mediaWaveform ? (typeof mediaWaveform === "string" ? JSON.parse(mediaWaveform) : mediaWaveform) : [],
      },
    });
  } catch (error: any) {
    console.error("Send message error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
