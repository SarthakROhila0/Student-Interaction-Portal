import { NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, users } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/lib/seed";
import { desc, eq, or } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    await ensureDatabaseSeeded();
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    let convs;
    if (userId) {
      convs = await db
        .select()
        .from(conversations)
        .where(or(eq(conversations.user1Id, userId), eq(conversations.user2Id, userId)))
        .orderBy(desc(conversations.isPinned), desc(conversations.lastMessageAt));
    } else {
      convs = await db
        .select()
        .from(conversations)
        .orderBy(desc(conversations.isPinned), desc(conversations.lastMessageAt));
    }

    // Populate user info for both participants
    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map((u) => [u.id, u]));

    const populated = convs.map((c) => ({
      ...c,
      user1: userMap.get(c.user1Id) || null,
      user2: userMap.get(c.user2Id) || null,
    }));

    return NextResponse.json({ success: true, conversations: populated });
  } catch (error: any) {
    console.error("Fetch conversations error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, user1Id, user2Id, type, description } = body;

    if (!user1Id || !user2Id) {
      return NextResponse.json({ success: false, error: "Both user IDs are required" }, { status: 400 });
    }

    const id = `conv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newConv = await db
      .insert(conversations)
      .values({
        id,
        title: title || "Direct Collaboration",
        type: type || "direct",
        user1Id,
        user2Id,
        description: description || "Interactive chat and document sharing channel",
        lastMessageText: "Conversation started",
        lastMessageAt: new Date(),
      })
      .returning();

    return NextResponse.json({ success: true, conversation: newConv[0] });
  } catch (error: any) {
    console.error("Create conversation error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
