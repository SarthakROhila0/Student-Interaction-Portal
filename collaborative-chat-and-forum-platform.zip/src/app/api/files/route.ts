import { NextResponse } from "next/server";
import { db } from "@/db";
import { sharedFiles, users } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/lib/seed";
import { desc, eq, and, ilike, or } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    await ensureDatabaseSeeded();
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const query = searchParams.get("query");
    const senderId = searchParams.get("senderId");

    let allFiles = await db.select().from(sharedFiles).orderBy(desc(sharedFiles.createdAt));

    if (category && category !== "all") {
      allFiles = allFiles.filter((f) => f.category.toLowerCase() === category.toLowerCase());
    }

    if (senderId) {
      allFiles = allFiles.filter((f) => f.senderId === senderId);
    }

    if (query) {
      const q = query.toLowerCase();
      allFiles = allFiles.filter(
        (f) =>
          f.fileName.toLowerCase().includes(q) ||
          f.description?.toLowerCase().includes(q) ||
          f.tags?.toLowerCase().includes(q)
      );
    }

    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map((u) => [u.id, u]));

    const populated = allFiles.map((file) => {
      let parsedTags: string[] = [];
      try {
        parsedTags = file.tags ? JSON.parse(file.tags) : [];
      } catch (e) {
        parsedTags = [];
      }
      return {
        ...file,
        sender: userMap.get(file.senderId) || null,
        tags: parsedTags,
      };
    });

    return NextResponse.json({ success: true, files: populated });
  } catch (error: any) {
    console.error("Fetch files error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { senderId, fileName, fileUrl, fileSize, mimeType, category, description, tags } = body;

    if (!senderId || !fileName || !fileUrl) {
      return NextResponse.json(
        { success: false, error: "Sender, fileName, and fileUrl are required" },
        { status: 400 }
      );
    }

    let cat = category || "document";
    if (!category) {
      if (mimeType?.startsWith("image/")) cat = "image";
      else if (mimeType?.startsWith("audio/")) cat = "voice";
      else if (fileName.endsWith(".ts") || fileName.endsWith(".js") || fileName.endsWith(".json")) cat = "code";
    }

    const inserted = await db
      .insert(sharedFiles)
      .values({
        senderId,
        fileName,
        fileUrl,
        fileSize: Number(fileSize) || 1024,
        mimeType: mimeType || "application/octet-stream",
        category: cat,
        description: description || "",
        tags: Array.isArray(tags) ? JSON.stringify(tags) : JSON.stringify([]),
        downloadsCount: 0,
        createdAt: new Date(),
      })
      .returning();

    const author = await db.select().from(users).where(eq(users.id, senderId));

    return NextResponse.json({
      success: true,
      file: {
        ...inserted[0],
        sender: author[0] || null,
        tags: tags || [],
      },
    });
  } catch (error: any) {
    console.error("Create file error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
