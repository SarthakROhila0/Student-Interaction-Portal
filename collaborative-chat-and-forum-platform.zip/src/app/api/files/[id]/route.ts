import { NextResponse } from "next/server";
import { db } from "@/db";
import { sharedFiles } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const fileId = parseInt(id, 10);
    if (isNaN(fileId)) {
      return NextResponse.json({ success: false, error: "Invalid file ID" }, { status: 400 });
    }

    const body = await request.json();
    if (body.action === "increment_download") {
      const updated = await db
        .update(sharedFiles)
        .set({ downloadsCount: sql`${sharedFiles.downloadsCount} + 1` })
        .where(eq(sharedFiles.id, fileId))
        .returning();

      return NextResponse.json({ success: true, file: updated[0] });
    }

    return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 });
  } catch (error: any) {
    console.error("Patch file error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const fileId = parseInt(id, 10);
    if (isNaN(fileId)) {
      return NextResponse.json({ success: false, error: "Invalid file ID" }, { status: 400 });
    }

    await db.delete(sharedFiles).where(eq(sharedFiles.id, fileId));
    return NextResponse.json({ success: true, deletedId: fileId });
  } catch (error: any) {
    console.error("Delete file error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
