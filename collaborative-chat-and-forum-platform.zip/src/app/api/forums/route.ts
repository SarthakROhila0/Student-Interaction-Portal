import { NextResponse } from "next/server";
import { db } from "@/db";
import { forums, forumThreads, users } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/lib/seed";
import { desc, eq, sql } from "drizzle-orm";

export async function GET() {
  try {
    await ensureDatabaseSeeded();
    const forumList = await db.select().from(forums).orderBy(desc(forums.createdAt));

    // Get all users
    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map((u) => [u.id, u]));

    // Count threads per forum
    const allThreads = await db.select().from(forumThreads);
    const threadCountMap = new Map<number, number>();
    for (const t of allThreads) {
      threadCountMap.set(t.forumId, (threadCountMap.get(t.forumId) || 0) + 1);
    }

    const populatedForums = forumList.map((f) => ({
      ...f,
      createdBy: userMap.get(f.createdById) || null,
      threadsCount: threadCountMap.get(f.id) || f.threadsCount || 0,
    }));

    return NextResponse.json({ success: true, forums: populatedForums });
  } catch (error: any) {
    console.error("Fetch forums error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, description, icon = "message-square", color = "indigo", createdById, isPrivate = false } = body;

    if (!title || !description || !createdById) {
      return NextResponse.json(
        { success: false, error: "Title, description, and createdById are required" },
        { status: 400 }
      );
    }

    const slug = title
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)+/g, "") + `-${Date.now().toString().slice(-4)}`;

    const newForum = await db
      .insert(forums)
      .values({
        slug,
        title,
        description,
        icon,
        color,
        createdById,
        threadsCount: 0,
        isPrivate: Boolean(isPrivate),
        createdAt: new Date(),
      })
      .returning();

    // Reward creator reputation
    await db
      .update(users)
      .set({ reputation: sql`${users.reputation} + 20` })
      .where(eq(users.id, createdById));

    const author = await db.select().from(users).where(eq(users.id, createdById));

    return NextResponse.json({
      success: true,
      forum: {
        ...newForum[0],
        createdBy: author[0] || null,
        threadsCount: 0,
      },
    });
  } catch (error: any) {
    console.error("Create forum error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
