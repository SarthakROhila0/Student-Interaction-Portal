import { NextResponse } from "next/server";
import { db } from "@/db";
import { forumThreads, forums, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const forumId = parseInt(id, 10);
    if (isNaN(forumId)) {
      return NextResponse.json({ success: false, error: "Invalid forum ID" }, { status: 400 });
    }

    const body = await request.json();
    const { authorId, title, content, tags = [], hasPoll = false, pollData = null, attachments = [], isPinned = false } = body;

    if (!authorId || !title || !content) {
      return NextResponse.json(
        { success: false, error: "Author, title, and content are required" },
        { status: 400 }
      );
    }

    const newThread = await db
      .insert(forumThreads)
      .values({
        forumId,
        authorId,
        title,
        content,
        tags: Array.isArray(tags) ? JSON.stringify(tags) : JSON.stringify([]),
        isPinned: Boolean(isPinned),
        isLocked: false,
        viewsCount: 1,
        likesCount: 0,
        repliesCount: 0,
        hasPoll: Boolean(hasPoll),
        pollData: pollData ? JSON.stringify(pollData) : null,
        attachments: Array.isArray(attachments) ? JSON.stringify(attachments) : JSON.stringify([]),
        lastActivityAt: new Date(),
        createdAt: new Date(),
      })
      .returning();

    // Increment forum thread count
    await db
      .update(forums)
      .set({ threadsCount: sql`${forums.threadsCount} + 1` })
      .where(eq(forums.id, forumId));

    // Award author reputation
    await db
      .update(users)
      .set({ reputation: sql`${users.reputation} + 15` })
      .where(eq(users.id, authorId));

    const author = await db.select().from(users).where(eq(users.id, authorId));

    return NextResponse.json({
      success: true,
      thread: {
        ...newThread[0],
        author: author[0] || null,
        tags: tags || [],
        pollData: pollData || null,
        attachments: attachments || [],
      },
    });
  } catch (error: any) {
    console.error("Create forum thread error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
