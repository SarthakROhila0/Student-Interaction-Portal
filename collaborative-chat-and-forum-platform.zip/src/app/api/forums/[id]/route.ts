import { NextResponse } from "next/server";
import { db } from "@/db";
import { forums, forumThreads, forumReplies, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const forumId = parseInt(id, 10);
    if (isNaN(forumId)) {
      return NextResponse.json({ success: false, error: "Invalid forum ID" }, { status: 400 });
    }

    const { searchParams } = new URL(request.url);
    const sort = searchParams.get("sort"); // latest, most_liked, most_replies
    const query = searchParams.get("query");

    const forum = await db.select().from(forums).where(eq(forums.id, forumId));
    if (forum.length === 0) {
      return NextResponse.json({ success: false, error: "Forum not found" }, { status: 404 });
    }

    let threads = await db
      .select()
      .from(forumThreads)
      .where(eq(forumThreads.forumId, forumId))
      .orderBy(desc(forumThreads.isPinned), desc(forumThreads.lastActivityAt));

    // Get all users
    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map((u) => [u.id, u]));

    // Search filter
    if (query) {
      const q = query.toLowerCase();
      threads = threads.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.content.toLowerCase().includes(q) ||
          t.tags?.toLowerCase().includes(q)
      );
    }

    // Sort
    if (sort === "most_liked") {
      threads.sort((a, b) => (b.likesCount || 0) - (a.likesCount || 0));
    } else if (sort === "most_replies") {
      threads.sort((a, b) => (b.repliesCount || 0) - (a.repliesCount || 0));
    }

    const populatedThreads = threads.map((t) => {
      let parsedTags = [];
      try {
        parsedTags = JSON.parse(t.tags || "[]");
      } catch {
        parsedTags = [];
      }

      let parsedPoll = null;
      try {
        parsedPoll = t.pollData ? JSON.parse(t.pollData) : null;
      } catch {
        parsedPoll = null;
      }

      return {
        ...t,
        author: userMap.get(t.authorId) || null,
        tags: parsedTags,
        pollData: parsedPoll,
      };
    });

    return NextResponse.json({
      success: true,
      forum: {
        ...forum[0],
        createdBy: userMap.get(forum[0].createdById) || null,
        threadsCount: threads.length,
      },
      threads: populatedThreads,
    });
  } catch (error: any) {
    console.error("Fetch forum details error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
