import { NextResponse } from "next/server";
import { db } from "@/db";
import { forumThreads, forumReplies, forums, users, forumLikes } from "@/db/schema";
import { asc, eq, sql } from "drizzle-orm";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ threadId: string }> }
) {
  try {
    const { threadId } = await params;
    const tid = parseInt(threadId, 10);
    if (isNaN(tid)) {
      return NextResponse.json({ success: false, error: "Invalid thread ID" }, { status: 400 });
    }

    // Increment view count
    await db
      .update(forumThreads)
      .set({ viewsCount: sql`${forumThreads.viewsCount} + 1` })
      .where(eq(forumThreads.id, tid));

    const t = await db.select().from(forumThreads).where(eq(forumThreads.id, tid));
    if (t.length === 0) {
      return NextResponse.json({ success: false, error: "Thread not found" }, { status: 404 });
    }

    const thread = t[0];
    const forumData = await db.select().from(forums).where(eq(forums.id, thread.forumId));

    // Get all users
    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map((u) => [u.id, u]));

    // Fetch replies
    const repliesList = await db
      .select()
      .from(forumReplies)
      .where(eq(forumReplies.threadId, tid))
      .orderBy(asc(forumReplies.createdAt));

    const populatedReplies = repliesList.map((r) => {
      let parsedAttachments = [];
      try {
        parsedAttachments = JSON.parse(r.attachments || "[]");
      } catch {
        parsedAttachments = [];
      }
      return {
        ...r,
        author: userMap.get(r.authorId) || null,
        attachments: parsedAttachments,
      };
    });

    let parsedTags = [];
    try {
      parsedTags = JSON.parse(thread.tags || "[]");
    } catch {
      parsedTags = [];
    }

    let parsedPoll = null;
    try {
      parsedPoll = thread.pollData ? JSON.parse(thread.pollData) : null;
    } catch {
      parsedPoll = null;
    }

    let parsedAttachments = [];
    try {
      parsedAttachments = JSON.parse(thread.attachments || "[]");
    } catch {
      parsedAttachments = [];
    }

    return NextResponse.json({
      success: true,
      thread: {
        ...thread,
        forum: forumData[0] || null,
        author: userMap.get(thread.authorId) || null,
        tags: parsedTags,
        pollData: parsedPoll,
        attachments: parsedAttachments,
        replies: populatedReplies,
      },
    });
  } catch (error: any) {
    console.error("Fetch thread error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
