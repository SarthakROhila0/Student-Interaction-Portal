import { NextResponse } from "next/server";
import { db } from "@/db";
import { forumThreads, forumReplies, forumLikes } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ threadId: string }> }
) {
  try {
    const { threadId } = await params;
    const tid = parseInt(threadId, 10);
    const body = await request.json();
    const { userId, targetType = "thread", targetId } = body; // targetType: 'thread' | 'reply'

    if (!userId) {
      return NextResponse.json({ success: false, error: "userId is required" }, { status: 400 });
    }

    const actualTargetId = targetType === "thread" ? tid : parseInt(targetId, 10);

    const existing = await db
      .select()
      .from(forumLikes)
      .where(
        and(
          eq(forumLikes.userId, userId),
          eq(forumLikes.targetType, targetType),
          eq(forumLikes.targetId, actualTargetId)
        )
      );

    let liked = false;
    if (existing.length > 0) {
      // Unlike
      await db.delete(forumLikes).where(eq(forumLikes.id, existing[0].id));
      if (targetType === "thread") {
        await db
          .update(forumThreads)
          .set({ likesCount: sql`GREATEST(0, ${forumThreads.likesCount} - 1)` })
          .where(eq(forumThreads.id, actualTargetId));
      } else {
        await db
          .update(forumReplies)
          .set({ likesCount: sql`GREATEST(0, ${forumReplies.likesCount} - 1)` })
          .where(eq(forumReplies.id, actualTargetId));
      }
      liked = false;
    } else {
      // Like
      await db.insert(forumLikes).values({
        userId,
        targetType,
        targetId: actualTargetId,
        createdAt: new Date(),
      });

      if (targetType === "thread") {
        await db
          .update(forumThreads)
          .set({ likesCount: sql`${forumThreads.likesCount} + 1` })
          .where(eq(forumThreads.id, actualTargetId));
      } else {
        await db
          .update(forumReplies)
          .set({ likesCount: sql`${forumReplies.likesCount} + 1` })
          .where(eq(forumReplies.id, actualTargetId));
      }
      liked = true;
    }

    return NextResponse.json({ success: true, liked, targetId: actualTargetId });
  } catch (error: any) {
    console.error("Forum like error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
