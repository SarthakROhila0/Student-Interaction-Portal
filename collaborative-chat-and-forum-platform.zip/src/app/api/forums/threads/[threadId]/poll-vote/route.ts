import { NextResponse } from "next/server";
import { db } from "@/db";
import { forumThreads } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ threadId: string }> }
) {
  try {
    const { threadId } = await params;
    const tid = parseInt(threadId, 10);
    if (isNaN(tid)) {
      return NextResponse.json({ success: false, error: "Invalid thread ID" }, { status: 400 });
    }

    const body = await request.json();
    const { userId, optionId } = body;

    if (!userId || optionId === undefined) {
      return NextResponse.json(
        { success: false, error: "userId and optionId are required" },
        { status: 400 }
      );
    }

    const thread = await db.select().from(forumThreads).where(eq(forumThreads.id, tid));
    if (thread.length === 0) {
      return NextResponse.json({ success: false, error: "Thread not found" }, { status: 404 });
    }

    const poll = thread[0].pollData ? JSON.parse(thread[0].pollData) : null;
    if (!poll || !poll.options) {
      return NextResponse.json({ success: false, error: "Poll not found on thread" }, { status: 400 });
    }

    // Remove user's previous votes and add new vote
    poll.options = poll.options.map((opt: any) => {
      const votes = (opt.votes || []).filter((u: string) => u !== userId);
      if (opt.id === Number(optionId)) {
        votes.push(userId);
      }
      return { ...opt, votes };
    });

    const updated = await db
      .update(forumThreads)
      .set({ pollData: JSON.stringify(poll) })
      .where(eq(forumThreads.id, tid))
      .returning();

    return NextResponse.json({ success: true, pollData: poll, thread: updated[0] });
  } catch (error: any) {
    console.error("Poll vote error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
