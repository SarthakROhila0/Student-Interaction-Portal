import { NextResponse } from "next/server";
import { db } from "@/db";
import { forumReplies, forumThreads, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ threadId: string }> }
) {
  try {
    const { threadId } = await params;
    const tid = parseInt(threadId, 10);
    if (isNaN(tid)) {
      return NextResponse.json({ success: false, error: "Invalid thread ID" }, { status: 400 });
    }

    const body = await request.json();
    const { authorId, content, replyToId = null, attachments = [] } = body;

    if (!authorId || !content) {
      return NextResponse.json(
        { success: false, error: "Author ID and content are required" },
        { status: 400 }
      );
    }

    const newReply = await db
      .insert(forumReplies)
      .values({
        threadId: tid,
        authorId,
        replyToId: replyToId ? Number(replyToId) : null,
        content,
        likesCount: 0,
        attachments: Array.isArray(attachments) ? JSON.stringify(attachments) : JSON.stringify([]),
        createdAt: new Date(),
      })
      .returning();

    // Increment repliesCount on thread & update lastActivityAt
    await db
      .update(forumThreads)
      .set({
        repliesCount: sql`${forumThreads.repliesCount} + 1`,
        lastActivityAt: new Date(),
      })
      .where(eq(forumThreads.id, tid));

    // Reward author reputation
    await db
      .update(users)
      .set({ reputation: sql`${users.reputation} + 5` })
      .where(eq(users.id, authorId));

    const author = await db.select().from(users).where(eq(users.id, authorId));

    return NextResponse.json({
      success: true,
      reply: {
        ...newReply[0],
        author: author[0] || null,
        attachments: attachments || [],
      },
    });
  } catch (error: any) {
    console.error("Post reply error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
