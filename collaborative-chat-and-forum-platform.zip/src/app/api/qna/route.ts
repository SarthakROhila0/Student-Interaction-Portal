import { NextResponse } from "next/server";
import { db } from "@/db";
import { qnaQuestions, qnaAnswers, users, qnaVotes } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/lib/seed";
import { desc, eq, sql } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    await ensureDatabaseSeeded();
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const tag = searchParams.get("tag");
    const status = searchParams.get("status"); // all, solved, unanswered
    const sort = searchParams.get("sort"); // latest, most_voted, most_answered
    const query = searchParams.get("query");

    let questionsList = await db
      .select()
      .from(qnaQuestions)
      .orderBy(desc(qnaQuestions.createdAt));

    // Get all answers to compute answer counts
    const allAnswers = await db.select().from(qnaAnswers);
    const answersCountMap = new Map<number, number>();
    for (const a of allAnswers) {
      answersCountMap.set(a.questionId, (answersCountMap.get(a.questionId) || 0) + 1);
    }

    // Get all users
    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map((u) => [u.id, u]));

    // Filter
    if (category && category !== "all") {
      questionsList = questionsList.filter(
        (q) => q.category.toLowerCase() === category.toLowerCase()
      );
    }

    if (tag) {
      questionsList = questionsList.filter((q) => {
        try {
          const tags = JSON.parse(q.tags || "[]");
          return tags.some((t: string) => t.toLowerCase() === tag.toLowerCase());
        } catch {
          return false;
        }
      });
    }

    if (status === "solved") {
      questionsList = questionsList.filter((q) => q.isSolved);
    } else if (status === "unanswered") {
      questionsList = questionsList.filter((q) => (answersCountMap.get(q.id) || 0) === 0);
    }

    if (query) {
      const q = query.toLowerCase();
      questionsList = questionsList.filter(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          item.content.toLowerCase().includes(q) ||
          item.tags?.toLowerCase().includes(q)
      );
    }

    // Sorting
    if (sort === "most_voted") {
      questionsList.sort((a, b) => (b.upvotesCount || 0) - (a.upvotesCount || 0));
    } else if (sort === "most_answered") {
      questionsList.sort(
        (a, b) => (answersCountMap.get(b.id) || 0) - (answersCountMap.get(a.id) || 0)
      );
    }

    const populated = questionsList.map((q) => {
      let parsedTags = [];
      try {
        parsedTags = JSON.parse(q.tags || "[]");
      } catch {
        parsedTags = [];
      }

      let parsedAttachments = [];
      try {
        parsedAttachments = JSON.parse(q.attachments || "[]");
      } catch {
        parsedAttachments = [];
      }

      return {
        ...q,
        author: userMap.get(q.authorId) || null,
        answersCount: answersCountMap.get(q.id) || 0,
        tags: parsedTags,
        attachments: parsedAttachments,
      };
    });

    return NextResponse.json({ success: true, questions: populated });
  } catch (error: any) {
    console.error("Fetch QnA questions error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { authorId, title, content, category, tags, attachments } = body;

    if (!authorId || !title || !content) {
      return NextResponse.json(
        { success: false, error: "Author, title, and content are required" },
        { status: 400 }
      );
    }

    const newQuestion = await db
      .insert(qnaQuestions)
      .values({
        authorId,
        title,
        content,
        category: category || "General",
        tags: Array.isArray(tags) ? JSON.stringify(tags) : JSON.stringify([]),
        viewsCount: 1,
        upvotesCount: 0,
        isSolved: false,
        attachments: Array.isArray(attachments) ? JSON.stringify(attachments) : JSON.stringify([]),
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();

    // Reward author reputation (+10)
    await db
      .update(users)
      .set({ reputation: sql`${users.reputation} + 10` })
      .where(eq(users.id, authorId));

    const author = await db.select().from(users).where(eq(users.id, authorId));

    return NextResponse.json({
      success: true,
      question: {
        ...newQuestion[0],
        author: author[0] || null,
        answersCount: 0,
        tags: tags || [],
        attachments: attachments || [],
      },
    });
  } catch (error: any) {
    console.error("Create QnA question error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
