import { NextResponse } from "next/server";
import { db } from "@/db";
import { qnaQuestions, qnaAnswers, users, qnaVotes } from "@/db/schema";
import { asc, desc, eq, sql } from "drizzle-orm";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const questionId = parseInt(id, 10);
    if (isNaN(questionId)) {
      return NextResponse.json({ success: false, error: "Invalid question ID" }, { status: 400 });
    }

    // Increment views
    await db
      .update(qnaQuestions)
      .set({ viewsCount: sql`${qnaQuestions.viewsCount} + 1` })
      .where(eq(qnaQuestions.id, questionId));

    const q = await db.select().from(qnaQuestions).where(eq(qnaQuestions.id, questionId));
    if (q.length === 0) {
      return NextResponse.json({ success: false, error: "Question not found" }, { status: 404 });
    }

    const question = q[0];

    // Fetch answers sorted by accepted status first, then upvotes desc
    const answersList = await db
      .select()
      .from(qnaAnswers)
      .where(eq(qnaAnswers.questionId, questionId))
      .orderBy(desc(qnaAnswers.isAccepted), desc(qnaAnswers.upvotesCount), asc(qnaAnswers.createdAt));

    // Get all users
    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map((u) => [u.id, u]));

    const populatedAnswers = answersList.map((a) => {
      let parsedAttachments = [];
      try {
        parsedAttachments = JSON.parse(a.attachments || "[]");
      } catch {
        parsedAttachments = [];
      }

      return {
        ...a,
        author: userMap.get(a.authorId) || null,
        attachments: parsedAttachments,
      };
    });

    let parsedTags = [];
    try {
      parsedTags = JSON.parse(question.tags || "[]");
    } catch {
      parsedTags = [];
    }

    let parsedAttachments = [];
    try {
      parsedAttachments = JSON.parse(question.attachments || "[]");
    } catch {
      parsedAttachments = [];
    }

    return NextResponse.json({
      success: true,
      question: {
        ...question,
        author: userMap.get(question.authorId) || null,
        tags: parsedTags,
        attachments: parsedAttachments,
        answers: populatedAnswers,
      },
    });
  } catch (error: any) {
    console.error("Fetch QnA single question error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
