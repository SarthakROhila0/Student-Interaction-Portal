import { NextResponse } from "next/server";
import { db } from "@/db";
import { qnaQuestions, qnaAnswers, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const questionId = parseInt(id, 10);
    if (isNaN(questionId)) {
      return NextResponse.json({ success: false, error: "Invalid question ID" }, { status: 400 });
    }

    const body = await request.json();
    const { answerId } = body;

    if (!answerId) {
      return NextResponse.json({ success: false, error: "Answer ID is required" }, { status: 400 });
    }

    // Unaccept all other answers for this question
    await db
      .update(qnaAnswers)
      .set({ isAccepted: false })
      .where(eq(qnaAnswers.questionId, questionId));

    // Mark the chosen answer as accepted
    const updatedAnswer = await db
      .update(qnaAnswers)
      .set({ isAccepted: true })
      .where(eq(qnaAnswers.id, answerId))
      .returning();

    // Mark question as solved
    const updatedQuestion = await db
      .update(qnaQuestions)
      .set({ isSolved: true, acceptedAnswerId: answerId })
      .where(eq(qnaQuestions.id, questionId))
      .returning();

    // Award answer author with +25 reputation for verified solution
    if (updatedAnswer.length > 0) {
      await db
        .update(users)
        .set({ reputation: sql`${users.reputation} + 25` })
        .where(eq(users.id, updatedAnswer[0].authorId));
    }

    return NextResponse.json({
      success: true,
      question: updatedQuestion[0],
      answer: updatedAnswer[0],
    });
  } catch (error: any) {
    console.error("Accept answer error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
