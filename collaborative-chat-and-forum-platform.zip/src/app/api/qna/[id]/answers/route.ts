import { NextResponse } from "next/server";
import { db } from "@/db";
import { qnaQuestions, qnaAnswers, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const questionId = parseInt(id, 10);
    if (isNaN(questionId)) {
      return NextResponse.json({ success: false, error: "Invalid question ID" }, { status: 400 });
    }

    const body = await request.json();
    const { authorId, content, attachments } = body;

    if (!authorId || !content) {
      return NextResponse.json(
        { success: false, error: "Author and content are required" },
        { status: 400 }
      );
    }

    const newAnswer = await db
      .insert(qnaAnswers)
      .values({
        questionId,
        authorId,
        content,
        upvotesCount: 0,
        isAccepted: false,
        attachments: Array.isArray(attachments) ? JSON.stringify(attachments) : JSON.stringify([]),
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();

    // Reward answer author with reputation points
    await db
      .update(users)
      .set({ reputation: sql`${users.reputation} + 15` })
      .where(eq(users.id, authorId));

    const author = await db.select().from(users).where(eq(users.id, authorId));

    return NextResponse.json({
      success: true,
      answer: {
        ...newAnswer[0],
        author: author[0] || null,
        attachments: attachments || [],
      },
    });
  } catch (error: any) {
    console.error("Post answer error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
