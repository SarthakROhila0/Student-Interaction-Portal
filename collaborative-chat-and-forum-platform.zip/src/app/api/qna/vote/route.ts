import { NextResponse } from "next/server";
import { db } from "@/db";
import { qnaQuestions, qnaAnswers, qnaVotes, users } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { userId, targetType, targetId, voteType = 1 } = body; // targetType: 'question' | 'answer'

    if (!userId || !targetType || !targetId) {
      return NextResponse.json(
        { success: false, error: "userId, targetType, and targetId are required" },
        { status: 400 }
      );
    }

    const numericTargetId = parseInt(targetId, 10);

    // Check existing vote
    const existingVote = await db
      .select()
      .from(qnaVotes)
      .where(
        and(
          eq(qnaVotes.userId, userId),
          eq(qnaVotes.targetType, targetType),
          eq(qnaVotes.targetId, numericTargetId)
        )
      );

    let voteDiff = voteType;

    if (existingVote.length > 0) {
      const prev = existingVote[0];
      if (prev.voteType === voteType) {
        // Toggle off / remove vote
        await db.delete(qnaVotes).where(eq(qnaVotes.id, prev.id));
        voteDiff = -voteType;
      } else {
        // Switch vote (e.g. from -1 to 1 => delta is 2)
        await db
          .update(qnaVotes)
          .set({ voteType })
          .where(eq(qnaVotes.id, prev.id));
        voteDiff = voteType - prev.voteType;
      }
    } else {
      await db.insert(qnaVotes).values({
        userId,
        targetType,
        targetId: numericTargetId,
        voteType,
        createdAt: new Date(),
      });
    }

    // Apply delta to target
    if (targetType === "question") {
      const updated = await db
        .update(qnaQuestions)
        .set({ upvotesCount: sql`${qnaQuestions.upvotesCount} + ${voteDiff}` })
        .where(eq(qnaQuestions.id, numericTargetId))
        .returning();

      return NextResponse.json({ success: true, target: updated[0] });
    } else {
      const updated = await db
        .update(qnaAnswers)
        .set({ upvotesCount: sql`${qnaAnswers.upvotesCount} + ${voteDiff}` })
        .where(eq(qnaAnswers.id, numericTargetId))
        .returning();

      return NextResponse.json({ success: true, target: updated[0] });
    }
  } catch (error: any) {
    console.error("QnA vote error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
