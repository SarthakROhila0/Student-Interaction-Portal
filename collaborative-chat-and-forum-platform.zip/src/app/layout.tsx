import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "OmniSync Portal | 2-User Chat, Media Vault, Q&A & Community Forums",
  description:
    "Interactive portal where 2 users collaborate through chat, document uploads, image galleries, audio voice notes, structured Q&A, and community forums.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased bg-slate-950 text-slate-100 min-h-screen">
        {children}
      </body>
    </html>
  );
}
