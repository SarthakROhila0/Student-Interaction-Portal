"use client";

import React from "react";
import { UserProvider, useUser } from "@/context/UserContext";
import { Navbar } from "@/components/layout/Navbar";
import { ChatSection } from "@/components/chat/ChatSection";
import { VaultSection } from "@/components/vault/VaultSection";
import { QnaSection } from "@/components/qna/QnaSection";
import { ForumsSection } from "@/components/forums/ForumsSection";
import { ScratchpadSection } from "@/components/scratchpad/ScratchpadSection";
import { SplitViewScreen } from "@/components/split/SplitViewScreen";

function MainPortalContent() {
  const { activeTab, splitScreenMode } = useUser();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {splitScreenMode ? (
          <SplitViewScreen />
        ) : (
          <>
            {activeTab === "chat" && (
              <div className="h-[calc(100vh-150px)] min-h-[650px]">
                <ChatSection />
              </div>
            )}
            {activeTab === "vault" && <VaultSection />}
            {activeTab === "qna" && <QnaSection />}
            {activeTab === "forums" && <ForumsSection />}
            {activeTab === "scratchpad" && <ScratchpadSection />}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>OmniSync 2-User Interactive Portal • Direct Chat, Media Vault, Q&A & Forums</div>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="text-slate-400">PostgreSQL + Drizzle ORM</span>
            <span>•</span>
            <span className="text-slate-400">WebAudio Recording</span>
            <span>•</span>
            <span className="text-slate-400">App Router Next.js</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function Home() {
  return (
    <UserProvider>
      <MainPortalContent />
    </UserProvider>
  );
}
