"use client";

import React, { useState, useEffect } from "react";
import {
  HelpCircle,
  CheckCircle2,
  Clock,
  Flame,
  Plus,
  Search,
  MessageSquare,
  ChevronUp,
  Tag,
  Sparkles,
} from "lucide-react";
import { QnaQuestion } from "@/types";
import { useUser } from "@/context/UserContext";
import { formatTimeAgo } from "@/lib/utils";
import { QuestionDetailModal } from "./QuestionDetailModal";

export function QnaSection() {
  const { currentUser } = useUser();
  const [questions, setQuestions] = useState<QnaQuestion[]>([]);
  const [activeStatus, setActiveStatus] = useState<string>("all");
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  // Modals
  const [selectedQuestionId, setSelectedQuestionId] = useState<number | null>(null);
  const [showAskModal, setShowAskModal] = useState(false);

  // New question form state
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [newCategory, setNewCategory] = useState("Architecture");
  const [newTags, setNewTags] = useState("Postgres, Sync");
  const [isSubmittingQuestion, setIsSubmittingQuestion] = useState(false);

  const fetchQuestions = async () => {
    try {
      let url = "/api/qna";
      const params = new URLSearchParams();
      if (activeStatus !== "all") {
        if (activeStatus === "most_voted") params.append("sort", "most_voted");
        else params.append("status", activeStatus);
      }
      if (activeCategory !== "all") params.append("category", activeCategory);
      if (searchQuery) params.append("query", searchQuery);
      if (params.toString()) url += `?${params.toString()}`;

      const res = await fetch(url);
      const data = await res.json();
      if (data.success && Array.isArray(data.questions)) {
        setQuestions(data.questions);
      }
    } catch (err) {
      console.error("Failed to load QnA questions:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchQuestions();
  }, [activeStatus, activeCategory, searchQuery]);

  const handleCreateQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !newTitle.trim() || !newContent.trim()) return;

    setIsSubmittingQuestion(true);
    try {
      const parsedTags = newTags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean);

      const res = await fetch("/api/qna", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authorId: currentUser.id,
          title: newTitle.trim(),
          content: newContent.trim(),
          category: newCategory,
          tags: parsedTags,
        }),
      });

      const data = await res.json();
      if (data.success && data.question) {
        setQuestions((prev) => [data.question, ...prev]);
        setShowAskModal(false);
        setNewTitle("");
        setNewContent("");
      }
    } catch (err) {
      console.error("Create question failed:", err);
    } finally {
      setIsSubmittingQuestion(false);
    }
  };

  const statusFilters = [
    { id: "all", label: "All Questions", icon: HelpCircle },
    { id: "solved", label: "Solved & Verified", icon: CheckCircle2 },
    { id: "unanswered", label: "Needs Answer", icon: Clock },
    { id: "most_voted", label: "Top Voted", icon: Flame },
  ];

  const categories = ["all", "Architecture", "UI/UX", "NextJS", "Database", "General"];

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-md relative overflow-hidden shadow-xl">
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-semibold text-purple-400 mb-2">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Collaborative Q&A Knowledge Exchange</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Questions & Solutions Base
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Ask technical queries, propose architectures, exchange answers, and award verified solutions with live reputation gains.
            </p>
          </div>

          <button
            onClick={() => setShowAskModal(true)}
            className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition cursor-pointer self-start sm:self-auto shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Ask a Question (+10 Rep)</span>
          </button>
        </div>

        {/* Filter Controls & Search */}
        <div className="mt-8 flex flex-col md:flex-row items-center justify-between gap-4 pt-6 border-t border-slate-800/80">
          {/* Status Filters */}
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
            {statusFilters.map((flt) => {
              const Icon = flt.icon;
              const isActive = activeStatus === flt.id;
              return (
                <button
                  key={flt.id}
                  onClick={() => setActiveStatus(flt.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-medium flex items-center gap-2 transition cursor-pointer shrink-0 ${
                    isActive
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                      : "bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/50"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{flt.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search questions or keywords..."
              className="w-full bg-slate-950/80 border border-slate-800 rounded-xl py-2 pl-9 pr-4 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 mt-3 overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer ${
                activeCategory === cat
                  ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/40"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {cat === "all" ? "All Categories" : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Questions List */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center p-12 text-slate-400">
          <Sparkles className="w-6 h-6 animate-spin text-indigo-400 mb-2" />
          <span className="text-xs">Loading Q&A discussions...</span>
        </div>
      ) : questions.length === 0 ? (
        <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-12 text-center text-slate-400">
          <HelpCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-300">No questions found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Be the first to post a question and start an interactive discussion!
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {questions.map((q) => (
            <div
              key={q.id}
              onClick={() => setSelectedQuestionId(q.id)}
              className={`bg-slate-900/90 border rounded-2xl p-5 sm:p-6 transition hover:shadow-xl cursor-pointer group relative overflow-hidden ${
                q.isSolved
                  ? "border-emerald-500/30 hover:border-emerald-500/60"
                  : "border-slate-800 hover:border-indigo-500/50"
              }`}
            >
              <div className="flex items-start gap-4 sm:gap-6">
                {/* Stats Left Column */}
                <div className="flex sm:flex-col items-center gap-3 sm:gap-2 shrink-0 text-center">
                  {/* Upvotes */}
                  <div className="px-2.5 py-1 sm:py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60 flex flex-col items-center min-w-[48px]">
                    <ChevronUp className="w-3.5 h-3.5 text-indigo-400" />
                    <span className="text-xs font-bold font-mono text-white">
                      {q.upvotesCount}
                    </span>
                    <span className="text-[9px] text-slate-400 uppercase">votes</span>
                  </div>

                  {/* Answers count badge */}
                  <div
                    className={`px-2.5 py-1 sm:py-1.5 rounded-xl flex flex-col items-center min-w-[48px] border ${
                      q.isSolved
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                        : (q.answersCount || 0) > 0
                        ? "bg-indigo-500/10 text-indigo-300 border-indigo-500/30"
                        : "bg-slate-800/40 text-slate-400 border-slate-800"
                    }`}
                  >
                    <span className="text-xs font-bold font-mono">
                      {q.answersCount || 0}
                    </span>
                    <span className="text-[9px] uppercase">
                      {q.isSolved ? "solved" : "ans"}
                    </span>
                  </div>
                </div>

                {/* Main Content Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className="px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                      {q.category}
                    </span>
                    {q.isSolved && (
                      <span className="px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Verified Solution</span>
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors leading-snug line-clamp-2">
                    {q.title}
                  </h3>

                  <p className="text-xs text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                    {q.content}
                  </p>

                  {/* Tags & Author footer */}
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                    {/* Tags */}
                    <div className="flex flex-wrap gap-1.5">
                      {q.tags &&
                        q.tags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px]"
                          >
                            #{tag}
                          </span>
                        ))}
                    </div>

                    {/* Author Meta */}
                    <div className="flex items-center gap-2 text-slate-400">
                      {q.author && (
                        <img
                          src={q.author.avatar}
                          alt={q.author.name}
                          className="w-5 h-5 rounded-full object-cover ring-1 ring-slate-700"
                        />
                      )}
                      <span className="text-slate-200 font-medium">{q.author?.name}</span>
                      <span>•</span>
                      <span>{formatTimeAgo(q.createdAt)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Ask Question Modal */}
      {showAskModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-xl p-6 shadow-2xl relative">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white">Ask a Technical Question</h3>
              </div>
              <button
                onClick={() => setShowAskModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateQuestion} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Question Title
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. How to structure Drizzle migrations with real-time push?"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Category
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Architecture">Architecture</option>
                    <option value="UI/UX">UI/UX & Design</option>
                    <option value="NextJS">Next.js & React</option>
                    <option value="Database">Database & SQL</option>
                    <option value="General">General</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Tags (comma separated)
                  </label>
                  <input
                    type="text"
                    value={newTags}
                    onChange={(e) => setNewTags(e.target.value)}
                    placeholder="NextJS, Postgres, Realtime"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Detailed Explanation & Context
                </label>
                <textarea
                  rows={5}
                  required
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="Describe your issue, requirements, or code snippets in detail..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500 font-sans"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAskModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingQuestion || !newTitle.trim() || !newContent.trim()}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition cursor-pointer"
                >
                  {isSubmittingQuestion ? "Publishing..." : "Publish Question (+10 Rep)"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Detailed Question View Modal */}
      <QuestionDetailModal
        isOpen={!!selectedQuestionId}
        questionId={selectedQuestionId}
        onClose={() => setSelectedQuestionId(null)}
        onQuestionUpdated={fetchQuestions}
      />
    </div>
  );
}
