"use client";

import React, { useState, useEffect } from "react";
import {
  HelpCircle,
  CheckCircle2,
  ChevronUp,
  ChevronDown,
  MessageSquare,
  Sparkles,
  Send,
  Code,
  Tag,
  Calendar,
  X,
  Award,
} from "lucide-react";
import { QnaQuestion, QnaAnswer, User } from "@/types";
import { useUser } from "@/context/UserContext";
import { formatTimeAgo } from "@/lib/utils";

interface QuestionDetailModalProps {
  isOpen: boolean;
  questionId: number | null;
  onClose: () => void;
  onQuestionUpdated: () => void;
}

export function QuestionDetailModal({
  isOpen,
  questionId,
  onClose,
  onQuestionUpdated,
}: QuestionDetailModalProps) {
  const { currentUser, triggerCelebration } = useUser();
  const [question, setQuestion] = useState<QnaQuestion | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [answerContent, setAnswerContent] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchQuestionDetails = async () => {
    if (!questionId) return;
    try {
      const res = await fetch(`/api/qna/${questionId}`);
      const data = await res.json();
      if (data.success && data.question) {
        setQuestion(data.question);
      }
    } catch (err) {
      console.error("Failed to load question details:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && questionId) {
      setIsLoading(true);
      fetchQuestionDetails();
    }
  }, [isOpen, questionId]);

  const handleVote = async (targetType: "question" | "answer", targetId: number, voteType: number) => {
    if (!currentUser) return;
    try {
      await fetch("/api/qna/vote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          targetType,
          targetId,
          voteType,
        }),
      });
      fetchQuestionDetails();
      onQuestionUpdated();
    } catch (err) {
      console.error("Vote failed:", err);
    }
  };

  const handleAcceptAnswer = async (answerId: number) => {
    if (!questionId) return;
    try {
      const res = await fetch(`/api/qna/${questionId}/accept`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answerId }),
      });
      const data = await res.json();
      if (data.success) {
        triggerCelebration();
        fetchQuestionDetails();
        onQuestionUpdated();
      }
    } catch (err) {
      console.error("Accept answer failed:", err);
    }
  };

  const handleSubmitAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !questionId || !answerContent.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/qna/${questionId}/answers`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authorId: currentUser.id,
          content: answerContent.trim(),
        }),
      });

      const data = await res.json();
      if (data.success) {
        setAnswerContent("");
        fetchQuestionDetails();
        onQuestionUpdated();
      }
    } catch (err) {
      console.error("Submit answer failed:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen || !questionId) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden relative">
        {/* Top Header */}
        <div className="p-5 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              {question?.category || "Q&A"}
            </span>
            {question?.isSolved && (
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Solved & Verified</span>
              </span>
            )}
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Question & Answers Scroll Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {isLoading || !question ? (
            <div className="flex flex-col items-center justify-center p-12 text-slate-400">
              <Sparkles className="w-6 h-6 animate-spin text-indigo-400 mb-2" />
              <span className="text-xs">Loading question thread...</span>
            </div>
          ) : (
            <>
              {/* Question Main Card */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-6 relative">
                <div className="flex items-start gap-4">
                  {/* Vote Column */}
                  <div className="flex flex-col items-center shrink-0 bg-slate-900 border border-slate-800 rounded-xl p-1.5">
                    <button
                      onClick={() => handleVote("question", question.id, 1)}
                      className="p-1 rounded text-slate-400 hover:text-indigo-400 transition cursor-pointer"
                      title="Upvote Question"
                    >
                      <ChevronUp className="w-5 h-5" />
                    </button>
                    <span className="text-sm font-bold text-white my-0.5 font-mono">
                      {question.upvotesCount}
                    </span>
                    <button
                      onClick={() => handleVote("question", question.id, -1)}
                      className="p-1 rounded text-slate-400 hover:text-rose-400 transition cursor-pointer"
                      title="Downvote"
                    >
                      <ChevronDown className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Question Body */}
                  <div className="flex-1 min-w-0">
                    <h2 className="text-xl font-bold text-white leading-tight mb-3">
                      {question.title}
                    </h2>
                    <div className="text-sm text-slate-300 whitespace-pre-wrap leading-relaxed space-y-2">
                      {question.content}
                    </div>

                    {/* Tags */}
                    {question.tags && question.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mt-4">
                        {question.tags.map((t, idx) => (
                          <span
                            key={idx}
                            className="px-2.5 py-0.5 rounded-lg bg-slate-800 text-indigo-300 border border-indigo-500/20 text-xs font-medium"
                          >
                            #{t}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Author Meta */}
                    <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                      <div className="flex items-center gap-2">
                        {question.author && (
                          <img
                            src={question.author.avatar}
                            alt={question.author.name}
                            className="w-6 h-6 rounded-full object-cover ring-1 ring-indigo-500/40"
                          />
                        )}
                        <span className="text-slate-200 font-medium">
                          {question.author?.name || "Author"}
                        </span>
                        <span>•</span>
                        <span>{formatTimeAgo(question.createdAt)}</span>
                      </div>

                      <div className="text-slate-500 font-mono text-[11px]">
                        {question.viewsCount} views
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Answers Header */}
              <div className="flex items-center justify-between pt-2">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-indigo-400" />
                  <span>{question.answers?.length || 0} Answers</span>
                </h3>
                {question.isSolved && (
                  <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Verified Solution Accepted
                  </span>
                )}
              </div>

              {/* Answers List */}
              <div className="space-y-4">
                {question.answers && question.answers.length > 0 ? (
                  question.answers.map((ans) => {
                    const isAccepted = ans.isAccepted;
                    return (
                      <div
                        key={ans.id}
                        className={`rounded-2xl p-6 transition-all relative ${
                          isAccepted
                            ? "bg-emerald-950/20 border-2 border-emerald-500/60 shadow-lg shadow-emerald-950/40"
                            : "bg-slate-950/40 border border-slate-800"
                        }`}
                      >
                        {/* Solution Badge if accepted */}
                        {isAccepted && (
                          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold mb-3">
                            <Award className="w-3.5 h-3.5" />
                            <span>Accepted & Verified Solution (+25 Rep)</span>
                          </div>
                        )}

                        <div className="flex items-start gap-4">
                          {/* Vote Column */}
                          <div className="flex flex-col items-center shrink-0 bg-slate-900 border border-slate-800 rounded-xl p-1.5">
                            <button
                              onClick={() => handleVote("answer", ans.id, 1)}
                              className="p-1 rounded text-slate-400 hover:text-emerald-400 transition cursor-pointer"
                              title="Upvote Answer"
                            >
                              <ChevronUp className="w-5 h-5" />
                            </button>
                            <span className="text-sm font-bold text-white my-0.5 font-mono">
                              {ans.upvotesCount}
                            </span>
                            <button
                              onClick={() => handleVote("answer", ans.id, -1)}
                              className="p-1 rounded text-slate-400 hover:text-rose-400 transition cursor-pointer"
                              title="Downvote"
                            >
                              <ChevronDown className="w-5 h-5" />
                            </button>
                          </div>

                          {/* Answer Body */}
                          <div className="flex-1 min-w-0">
                            <div className="text-sm text-slate-200 whitespace-pre-wrap leading-relaxed font-sans">
                              {ans.content}
                            </div>

                            {/* Author Card & Accept Action */}
                            <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-400">
                              <div className="flex items-center gap-2">
                                {ans.author && (
                                  <img
                                    src={ans.author.avatar}
                                    alt={ans.author.name}
                                    className="w-6 h-6 rounded-full object-cover ring-1 ring-emerald-500/40"
                                  />
                                )}
                                <span className="text-slate-200 font-medium">
                                  {ans.author?.name || "Collaborator"}
                                </span>
                                <span>•</span>
                                <span>{formatTimeAgo(ans.createdAt)}</span>
                              </div>

                              {/* Accept solution button */}
                              {!isAccepted && (
                                <button
                                  onClick={() => handleAcceptAnswer(ans.id)}
                                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-emerald-600/30 text-slate-300 hover:text-emerald-300 border border-slate-700 hover:border-emerald-500/40 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer self-start sm:self-auto"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Accept as Verified Solution</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="p-8 text-center bg-slate-950/30 border border-slate-800/80 rounded-2xl text-slate-400 text-xs">
                    No answers posted yet. Be the first to answer and earn reputation!
                  </div>
                )}
              </div>

              {/* Submit Answer Form */}
              <div className="pt-4">
                <form onSubmit={handleSubmitAnswer} className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                      <Code className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Your Answer & Solution</span>
                    </label>
                    <span className="text-[11px] text-slate-500">Markdown formatting supported</span>
                  </div>

                  <textarea
                    rows={4}
                    required
                    value={answerContent}
                    onChange={(e) => setAnswerContent(e.target.value)}
                    placeholder="Write a clear, structured explanation or code example..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                  />

                  <div className="flex items-center justify-end">
                    <button
                      type="submit"
                      disabled={isSubmitting || !answerContent.trim()}
                      className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isSubmitting ? "Posting..." : "Post Solution (+15 Rep)"}</span>
                    </button>
                  </div>
                </form>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
