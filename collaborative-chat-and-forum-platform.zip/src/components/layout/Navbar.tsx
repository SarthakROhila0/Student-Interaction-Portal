"use client";

import React, { useState } from "react";
import {
  MessageSquare,
  Folder,
  HelpCircle,
  Users,
  Columns,
  RotateCcw,
  Sparkles,
  ChevronDown,
  Layers,
  FileCode,
  Shield,
  Award,
} from "lucide-react";
import { useUser } from "@/context/UserContext";

export function Navbar() {
  const {
    users,
    currentUser,
    partnerUser,
    switchPersona,
    splitScreenMode,
    setSplitScreenMode,
    activeTab,
    setActiveTab,
    refreshUsers,
  } = useUser();

  const [showPersonaMenu, setShowPersonaMenu] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  const handleResetData = async () => {
    if (!confirm("Reset demo workspace and re-seed fresh conversations, files, Q&A, and forums?")) {
      return;
    }

    setIsResetting(true);
    try {
      await fetch("/api/reset", { method: "POST" });
      await refreshUsers();
      window.location.reload();
    } catch (err) {
      console.error("Reset failed:", err);
    } finally {
      setIsResetting(false);
    }
  };

  const navItems = [
    { id: "chat", label: "Direct Chat", icon: MessageSquare, badge: "Live" },
    { id: "vault", label: "Media & Docs Vault", icon: Folder },
    { id: "qna", label: "Q&A Base", icon: HelpCircle, badge: "Solved" },
    { id: "forums", label: "Community Forums", icon: Users },
    { id: "scratchpad", label: "Live Scratchpad", icon: FileCode },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          {/* Brand Logo */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-600/30">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg text-white tracking-tight">
                  OmniSync<span className="text-indigo-400">.Portal</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  2-User Collab
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Direct Chat • Media Vault • Q&A • Community Forums
              </p>
            </div>
          </div>

          {/* Center Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-900/90 border border-slate-800/90 rounded-2xl p-1 shadow-inner">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id && !splitScreenMode;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setSplitScreenMode(false);
                    setActiveTab(item.id as any);
                  }}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition cursor-pointer relative ${
                    isActive
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.2 rounded-full ${
                        isActive
                          ? "bg-white/20 text-white"
                          : "bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right User Controls */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Split Screen Mode Toggle */}
            <button
              onClick={() => setSplitScreenMode(!splitScreenMode)}
              className={`px-3 sm:px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-2 transition cursor-pointer border shadow-sm ${
                splitScreenMode
                  ? "bg-purple-600 border-purple-400 text-white shadow-purple-600/40 shadow-md"
                  : "bg-slate-900/90 hover:bg-slate-800 border-slate-700/80 text-slate-300 hover:text-white"
              }`}
              title="Toggle Split Screen Dual-User Simulation"
            >
              <Columns className="w-4 h-4" />
              <span className="hidden sm:inline">
                {splitScreenMode ? "Split View (Active)" : "Dual Screen Mode"}
              </span>
            </button>

            {/* Persona Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowPersonaMenu((prev) => !prev)}
                className="flex items-center gap-2.5 bg-slate-900 border border-slate-700/80 hover:border-indigo-500/50 rounded-2xl p-1.5 pr-3 transition cursor-pointer group shadow-sm"
              >
                <div className="relative">
                  <img
                    src={currentUser?.avatar || "https://api.dicebear.com/7.x/avataaars/svg?seed=user"}
                    alt={currentUser?.name || "User"}
                    className="w-8 h-8 rounded-full object-cover ring-2 ring-indigo-500"
                  />
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-slate-900" />
                </div>

                <div className="text-left hidden lg:block">
                  <div className="text-xs font-bold text-white leading-tight flex items-center gap-1">
                    <span>{currentUser?.name || "Alex Rivera"}</span>
                    <span className="text-[10px] text-amber-300 font-mono flex items-center gap-0.5">
                      <Award className="w-3 h-3 text-amber-400" />
                      {currentUser?.reputation || 100}
                    </span>
                  </div>
                  <div className="text-[10px] text-indigo-400 font-medium">
                    Active: {currentUser?.role?.split(" ")[0] || "Architect"}
                  </div>
                </div>

                <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-white transition-transform" />
              </button>

              {/* Persona Switch Menu */}
              {showPersonaMenu && (
                <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-700/80 rounded-2xl p-2 shadow-2xl z-50 animate-in zoom-in-95">
                  <div className="px-3 py-2 text-xs font-semibold text-slate-400 border-b border-slate-800 flex items-center justify-between">
                    <span>Switch Active Persona</span>
                    <span className="text-[10px] text-indigo-400 font-mono">1-Click Switch</span>
                  </div>

                  <div className="py-1 space-y-1">
                    {users.map((u) => {
                      const isSelected = currentUser?.id === u.id;
                      return (
                        <button
                          key={u.id}
                          onClick={() => {
                            switchPersona(u.id);
                            setShowPersonaMenu(false);
                          }}
                          className={`w-full p-2.5 rounded-xl flex items-center gap-3 transition cursor-pointer text-left ${
                            isSelected
                              ? "bg-indigo-600/20 border border-indigo-500/40 text-white"
                              : "hover:bg-slate-800 text-slate-300 hover:text-white"
                          }`}
                        >
                          <img
                            src={u.avatar}
                            alt={u.name}
                            className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-700"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-bold truncate flex items-center justify-between">
                              <span className="truncate">{u.name}</span>
                              <span className="text-[10px] text-amber-400 font-mono shrink-0">
                                {u.reputation} Rep
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 truncate">{u.role}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Reset Demo button */}
                  <div className="pt-2 border-t border-slate-800">
                    <button
                      onClick={handleResetData}
                      disabled={isResetting}
                      className="w-full px-3 py-2 rounded-xl text-xs text-rose-400 hover:bg-rose-500/10 flex items-center justify-center gap-1.5 transition cursor-pointer"
                    >
                      <RotateCcw className={`w-3.5 h-3.5 ${isResetting ? "animate-spin" : ""}`} />
                      <span>{isResetting ? "Resetting data..." : "Reset Sample Data"}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Navigation Tabs */}
        <div className="flex md:hidden items-center gap-1 py-2 overflow-x-auto border-t border-slate-800/60">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id && !splitScreenMode;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setSplitScreenMode(false);
                  setActiveTab(item.id as any);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition ${
                  isActive
                    ? "bg-indigo-600 text-white"
                    : "text-slate-400 hover:text-white bg-slate-900/60"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
