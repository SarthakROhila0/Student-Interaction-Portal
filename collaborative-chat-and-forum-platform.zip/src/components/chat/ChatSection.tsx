"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  Phone,
  Video,
  Search,
  Pin,
  Folder,
  Sparkles,
  Info,
  Layers,
  CheckCircle2,
} from "lucide-react";
import { Message, User } from "@/types";
import { useUser } from "@/context/UserContext";
import { MessageItem } from "./MessageItem";
import { MessageInput } from "./MessageInput";
import { VoiceRecorderModal } from "@/components/common/VoiceRecorderModal";
import { DocumentViewerModal } from "@/components/common/DocumentViewerModal";
import { ImageLightboxModal } from "@/components/common/ImageLightboxModal";
import { CallSimulationModal } from "@/components/common/CallSimulationModal";

interface ChatSectionProps {
  forcedCurrentUser?: User | null;
  forcedPartnerUser?: User | null;
  compactMode?: boolean;
}

export function ChatSection({
  forcedCurrentUser,
  forcedPartnerUser,
  compactMode = false,
}: ChatSectionProps) {
  const { currentUser: contextUser, partnerUser: contextPartner, triggerCelebration } = useUser();
  const currentUser = forcedCurrentUser || contextUser;
  const partnerUser = forcedPartnerUser || contextPartner;

  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);
  const [showCallModal, setShowCallModal] = useState(false);
  const [isVideoCall, setIsVideoCall] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);

  // Modals state
  const [previewDoc, setPreviewDoc] = useState<any | null>(null);
  const [previewImage, setPreviewImage] = useState<any | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const conversationId = "conv_alex_elena";

  // Fetch messages
  const fetchMessages = async () => {
    try {
      const res = await fetch(`/api/chat/messages?conversationId=${conversationId}`);
      const data = await res.json();
      if (data.success && Array.isArray(data.messages)) {
        setMessages(data.messages);
      }
    } catch (err) {
      console.error("Failed to load messages:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Initial load + interval polling
  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 2500);
    return () => clearInterval(interval);
  }, [conversationId]);

  // Scroll to bottom on initial load or message count change
  useEffect(() => {
    if (!isLoading && messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages.length, isLoading]);

  // Send message handler
  const handleSendMessage = async (payload: {
    content?: string;
    type?: "text" | "image" | "document" | "voice" | "code";
    mediaUrl?: string;
    mediaName?: string;
    mediaSize?: number;
    mediaMime?: string;
    mediaDuration?: number;
    mediaWaveform?: number[];
    replyToId?: number | null;
  }) => {
    if (!currentUser || !partnerUser) return;

    try {
      const res = await fetch("/api/chat/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId,
          senderId: currentUser.id,
          receiverId: partnerUser.id,
          ...payload,
        }),
      });

      const data = await res.json();
      if (data.success && data.message) {
        setMessages((prev) => [...prev, data.message]);
      }
    } catch (err) {
      console.error("Failed to send message:", err);
    }
  };

  // Toggle reaction
  const handleReact = async (messageId: number, emoji: string) => {
    if (!currentUser) return;
    try {
      // Optimistic update
      setMessages((prev) =>
        prev.map((msg) => {
          if (msg.id !== messageId) return msg;
          const currentReactions = { ...(msg.reactions || {}) };
          if (!currentReactions[emoji]) currentReactions[emoji] = [];
          if (currentReactions[emoji].includes(currentUser.id)) {
            currentReactions[emoji] = currentReactions[emoji].filter((uid) => uid !== currentUser.id);
            if (currentReactions[emoji].length === 0) delete currentReactions[emoji];
          } else {
            currentReactions[emoji].push(currentUser.id);
          }
          return { ...msg, reactions: currentReactions };
        })
      );

      await fetch(`/api/chat/messages/${messageId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "toggle_reaction",
          emoji,
          userId: currentUser.id,
        }),
      });
    } catch (err) {
      console.error("React error:", err);
    }
  };

  // Toggle pin
  const handlePin = async (messageId: number) => {
    try {
      setMessages((prev) =>
        prev.map((m) => (m.id === messageId ? { ...m, isPinned: !m.isPinned } : m))
      );
      await fetch(`/api/chat/messages/${messageId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "toggle_pin" }),
      });
    } catch (err) {
      console.error("Pin error:", err);
    }
  };

  // Delete message
  const handleDelete = async (messageId: number) => {
    try {
      setMessages((prev) => prev.filter((m) => m.id !== messageId));
      await fetch(`/api/chat/messages/${messageId}`, { method: "DELETE" });
    } catch (err) {
      console.error("Delete error:", err);
    }
  };

  // Call ended log
  const handleCallEnded = (durationSec: number) => {
    if (durationSec > 0) {
      handleSendMessage({
        content: `📞 Finished call with ${partnerUser?.name} (${Math.floor(durationSec / 60)}m ${durationSec % 60}s)`,
        type: "code",
      });
    }
  };

  const filteredMessages = messages.filter((m) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      m.content?.toLowerCase().includes(q) ||
      m.mediaName?.toLowerCase().includes(q) ||
      m.sender?.name?.toLowerCase().includes(q)
    );
  });

  const pinnedMessages = messages.filter((m) => m.isPinned);

  return (
    <div className="flex flex-col h-full bg-slate-950/60 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden relative">
      {/* Chat Top Header */}
      <div className="p-3.5 sm:p-4 bg-slate-900/90 border-b border-slate-800/80 flex items-center justify-between backdrop-blur-md z-10">
        {/* Partner Profile Summary */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative shrink-0">
            <img
              src={partnerUser?.avatar || "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80"}
              alt={partnerUser?.name || "Partner"}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/30"
            />
            <span
              className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-900 ${
                partnerUser?.status === "online"
                  ? "bg-emerald-400"
                  : partnerUser?.status === "busy"
                  ? "bg-rose-400"
                  : "bg-amber-400"
              }`}
            />
          </div>

          <div className="truncate">
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold text-white truncate">
                {partnerUser?.name || "Elena Chen"}
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-medium hidden sm:inline-block">
                {partnerUser?.department || "Product"}
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate">
              {partnerUser?.statusMessage || partnerUser?.role || "Active in workspace"}
            </p>
          </div>
        </div>

        {/* Right Header Action Icons */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Search in Chat Button */}
          <button
            onClick={() => setIsSearchOpen((prev) => !prev)}
            className={`p-2 rounded-xl text-xs transition cursor-pointer ${
              isSearchOpen
                ? "bg-indigo-600 text-white shadow-indigo-600/30 shadow"
                : "bg-slate-800/80 hover:bg-slate-800 text-slate-300"
            }`}
            title="Search in Chat"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Voice Call Simulation */}
          <button
            onClick={() => {
              setIsVideoCall(false);
              setShowCallModal(true);
            }}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-emerald-500/20 text-slate-300 hover:text-emerald-400 border border-slate-700/60 transition cursor-pointer"
            title="Start Audio Call"
          >
            <Phone className="w-4 h-4" />
          </button>

          {/* Video Call Simulation */}
          <button
            onClick={() => {
              setIsVideoCall(true);
              setShowCallModal(true);
            }}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-indigo-500/20 text-slate-300 hover:text-indigo-400 border border-slate-700/60 transition cursor-pointer"
            title="Start Video Call"
          >
            <Video className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* In-Chat Search Bar Drawer */}
      {isSearchOpen && (
        <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center gap-2 animate-in slide-in-from-top-2">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search messages, documents, code..."
            className="flex-1 bg-transparent text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none"
            autoFocus
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="text-xs text-slate-400 hover:text-white px-1"
            >
              Clear
            </button>
          )}
        </div>
      )}

      {/* Pinned Messages Header Ribbon */}
      {pinnedMessages.length > 0 && (
        <div className="bg-indigo-950/70 border-b border-indigo-500/30 px-4 py-1.5 flex items-center justify-between text-xs text-indigo-200">
          <div className="flex items-center gap-2 truncate">
            <Pin className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="font-semibold text-indigo-300">{pinnedMessages.length} Pinned:</span>
            <span className="truncate text-slate-300">
              {pinnedMessages[pinnedMessages.length - 1].content ||
                pinnedMessages[pinnedMessages.length - 1].mediaName}
            </span>
          </div>
        </div>
      )}

      {/* Messages Stream Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-2">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full text-slate-400 space-y-2">
            <Sparkles className="w-6 h-6 animate-spin text-indigo-400" />
            <span className="text-xs font-medium">Synchronizing encrypted messages...</span>
          </div>
        ) : filteredMessages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6 text-slate-400">
            <Info className="w-8 h-8 text-slate-600 mb-2" />
            <p className="text-sm font-semibold text-slate-300">No messages found</p>
            <p className="text-xs text-slate-500 mt-1">
              Start the conversation, record a voice note, or drop a document!
            </p>
          </div>
        ) : (
          filteredMessages.map((msg) => (
            <MessageItem
              key={msg.id}
              message={msg}
              currentUser={currentUser}
              onReact={handleReact}
              onPin={handlePin}
              onDelete={handleDelete}
              onReply={(m) => setReplyingTo(m)}
              onPreviewDocument={(doc) => setPreviewDoc(doc)}
              onPreviewImage={(img) => setPreviewImage(img)}
            />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input Bottom Bar */}
      <MessageInput
        onSendMessage={handleSendMessage}
        onOpenVoiceRecorder={() => setShowVoiceRecorder(true)}
        replyingTo={replyingTo}
        onCancelReply={() => setReplyingTo(null)}
      />

      {/* Voice Recorder Modal */}
      <VoiceRecorderModal
        isOpen={showVoiceRecorder}
        onClose={() => setShowVoiceRecorder(false)}
        onSendVoiceNote={(audioData) => {
          handleSendMessage({
            content: `🎤 Voice note (${audioData.fileName})`,
            type: "voice",
            mediaUrl: audioData.dataUrl,
            mediaName: audioData.fileName,
            mediaDuration: audioData.duration,
            mediaWaveform: audioData.waveform,
            mediaMime: "audio/webm",
            mediaSize: audioData.dataUrl.length,
          });
        }}
      />

      {/* Document Viewer Modal */}
      <DocumentViewerModal
        isOpen={!!previewDoc}
        onClose={() => setPreviewDoc(null)}
        document={previewDoc}
      />

      {/* Image Lightbox Modal */}
      <ImageLightboxModal
        isOpen={!!previewImage}
        onClose={() => setPreviewImage(null)}
        imageUrl={previewImage?.imageUrl || null}
        imageName={previewImage?.imageName || null}
        imageSize={previewImage?.imageSize || null}
        caption={previewImage?.caption || null}
      />

      {/* Audio/Video Call Simulation Modal */}
      <CallSimulationModal
        isOpen={showCallModal}
        onClose={() => setShowCallModal(false)}
        currentUser={currentUser}
        partnerUser={partnerUser}
        isVideoCall={isVideoCall}
        onCallEnded={handleCallEnded}
      />
    </div>
  );
}
