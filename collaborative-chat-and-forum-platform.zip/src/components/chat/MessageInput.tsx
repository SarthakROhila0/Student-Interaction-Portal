"use client";

import React, { useState, useRef } from "react";
import {
  Send,
  Paperclip,
  Image as ImageIcon,
  FileText,
  Mic,
  Smile,
  Code,
  X,
  Sparkles,
} from "lucide-react";
import { Message } from "@/types";

interface MessageInputProps {
  onSendMessage: (payload: {
    content?: string;
    type?: "text" | "image" | "document" | "voice" | "code";
    mediaUrl?: string;
    mediaName?: string;
    mediaSize?: number;
    mediaMime?: string;
    mediaDuration?: number;
    mediaWaveform?: number[];
    replyToId?: number | null;
  }) => Promise<void>;
  onOpenVoiceRecorder: () => void;
  replyingTo: Message | null;
  onCancelReply: () => void;
}

export function MessageInput({
  onSendMessage,
  onOpenVoiceRecorder,
  replyingTo,
  onCancelReply,
}: MessageInputProps) {
  const [text, setText] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const handleSendText = async () => {
    if (!text.trim()) return;
    const content = text.trim();
    setText("");

    await onSendMessage({
      content,
      type: "text",
      replyToId: replyingTo?.id || null,
    });

    if (replyingTo) onCancelReply();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendText();
    }
  };

  // Upload handler for document or image
  const handleFileSelected = async (
    e: React.ChangeEvent<HTMLInputElement>,
    expectedType: "document" | "image"
  ) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    setIsUploading(true);
    setShowAttachMenu(false);

    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Url = reader.result as string;

        await onSendMessage({
          content: `${expectedType === "image" ? "📷 Image" : "📄 Document"}: ${file.name}`,
          type: expectedType,
          mediaUrl: base64Url,
          mediaName: file.name,
          mediaSize: file.size,
          mediaMime: file.type || (expectedType === "image" ? "image/jpeg" : "application/pdf"),
          replyToId: replyingTo?.id || null,
        });

        if (replyingTo) onCancelReply();
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error("Upload error:", err);
    } finally {
      setIsUploading(false);
      e.target.value = "";
    }
  };

  const insertCodeTemplate = () => {
    setText((prev) => prev + "```typescript\n// Quick technical snippet\nexport const syncConfig = {\n  interval: 2500\n};\n```\n");
    setShowAttachMenu(false);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const addEmoji = (emoji: string) => {
    setText((prev) => prev + emoji);
    setShowEmojiPicker(false);
  };

  return (
    <div className="relative border-t border-slate-800 bg-slate-950/80 backdrop-blur-md p-3 sm:p-4">
      {/* Hidden File Inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.doc,.docx,.txt,.json,.ts,.js,.sql,.csv,.zip"
        className="hidden"
        onChange={(e) => handleFileSelected(e, "document")}
      />
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFileSelected(e, "image")}
      />

      {/* Replying banner */}
      {replyingTo && (
        <div className="mb-2 p-2 bg-indigo-950/60 border border-indigo-500/30 rounded-xl flex items-center justify-between text-xs text-indigo-200">
          <div className="flex items-center gap-2 truncate">
            <span className="font-semibold text-indigo-400">
              Replying to {replyingTo.sender?.name || "message"}:
            </span>
            <span className="truncate text-slate-300">
              {replyingTo.content || replyingTo.mediaName || "Attachment"}
            </span>
          </div>
          <button
            onClick={onCancelReply}
            className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Input Row */}
      <div className="flex items-end gap-2 bg-slate-900/90 border border-slate-700/70 rounded-2xl p-2 shadow-inner focus-within:border-indigo-500/80 transition-all">
        {/* Attachment Menu Button */}
        <div className="relative shrink-0">
          <button
            onClick={() => {
              setShowAttachMenu((prev) => !prev);
              setShowEmojiPicker(false);
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-indigo-400 hover:bg-slate-800 transition cursor-pointer"
            title="Attach Media or File"
          >
            <Paperclip className="w-5 h-5" />
          </button>

          {/* Attachment Popup Menu */}
          {showAttachMenu && (
            <div className="absolute bottom-full mb-2 left-0 z-30 bg-slate-900 border border-slate-700 rounded-2xl p-2 shadow-2xl w-48 space-y-1 animate-in zoom-in-95">
              <button
                onClick={() => {
                  imageInputRef.current?.click();
                  setShowAttachMenu(false);
                }}
                className="w-full px-3 py-2 rounded-xl text-xs flex items-center gap-2.5 text-slate-200 hover:bg-slate-800 hover:text-indigo-300 transition cursor-pointer"
              >
                <ImageIcon className="w-4 h-4 text-purple-400" />
                <span>Upload Image</span>
              </button>

              <button
                onClick={() => {
                  fileInputRef.current?.click();
                  setShowAttachMenu(false);
                }}
                className="w-full px-3 py-2 rounded-xl text-xs flex items-center gap-2.5 text-slate-200 hover:bg-slate-800 hover:text-indigo-300 transition cursor-pointer"
              >
                <FileText className="w-4 h-4 text-blue-400" />
                <span>Upload Document</span>
              </button>

              <button
                onClick={() => {
                  onOpenVoiceRecorder();
                  setShowAttachMenu(false);
                }}
                className="w-full px-3 py-2 rounded-xl text-xs flex items-center gap-2.5 text-slate-200 hover:bg-slate-800 hover:text-indigo-300 transition cursor-pointer"
              >
                <Mic className="w-4 h-4 text-emerald-400" />
                <span>Record Voice Note</span>
              </button>

              <button
                onClick={insertCodeTemplate}
                className="w-full px-3 py-2 rounded-xl text-xs flex items-center gap-2.5 text-slate-200 hover:bg-slate-800 hover:text-indigo-300 transition cursor-pointer"
              >
                <Code className="w-4 h-4 text-amber-400" />
                <span>Insert Code Snippet</span>
              </button>
            </div>
          )}
        </div>

        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type a message or paste a link... (Press Enter to send)"
          rows={1}
          className="flex-1 bg-transparent text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none resize-none max-h-32 min-h-[38px] py-2 px-1"
        />

        {/* Quick Voice Recorder Button */}
        <button
          onClick={onOpenVoiceRecorder}
          className="p-2 rounded-xl text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition cursor-pointer shrink-0"
          title="Record Voice Note"
        >
          <Mic className="w-5 h-5" />
        </button>

        {/* Quick Emoji Picker */}
        <div className="relative shrink-0">
          <button
            onClick={() => {
              setShowEmojiPicker((prev) => !prev);
              setShowAttachMenu(false);
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition cursor-pointer"
            title="Emoji"
          >
            <Smile className="w-5 h-5" />
          </button>

          {showEmojiPicker && (
            <div className="absolute bottom-full mb-2 right-0 z-30 bg-slate-900 border border-slate-700 rounded-2xl p-2 shadow-2xl grid grid-cols-4 gap-1 animate-in zoom-in-95">
              {["👋", "🔥", "🚀", "💡", "❤️", "👍", "🙌", "✨", "🎉", "⚡", "💻", "🎨"].map((e) => (
                <button
                  key={e}
                  onClick={() => addEmoji(e)}
                  className="p-1.5 text-lg hover:scale-125 transition-transform cursor-pointer"
                >
                  {e}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Send Button */}
        <button
          onClick={handleSendText}
          disabled={!text.trim() && !isUploading}
          className={`p-2.5 rounded-xl flex items-center justify-center transition shadow-md cursor-pointer shrink-0 ${
            text.trim()
              ? "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30 active:scale-95"
              : "bg-slate-800 text-slate-500 cursor-not-allowed"
          }`}
          title="Send Message"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

      {isUploading && (
        <div className="text-[11px] text-indigo-400 mt-1.5 flex items-center gap-1.5 px-2">
          <Sparkles className="w-3.5 h-3.5 animate-spin" />
          <span>Uploading attachment and indexing to shared vault...</span>
        </div>
      )}
    </div>
  );
}
