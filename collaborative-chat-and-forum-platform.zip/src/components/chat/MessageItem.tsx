"use client";

import React, { useState } from "react";
import {
  FileText,
  Download,
  Eye,
  Smile,
  Reply,
  Pin,
  MoreVertical,
  Trash2,
  Check,
  CheckCheck,
  PhoneCall,
  Code,
} from "lucide-react";
import { Message, User } from "@/types";
import { formatBytes, formatMessageTime } from "@/lib/utils";
import { AudioWavePlayer } from "@/components/common/AudioWavePlayer";

interface MessageItemProps {
  message: Message;
  currentUser: User | null;
  onReact: (messageId: number, emoji: string) => void;
  onPin: (messageId: number) => void;
  onDelete: (messageId: number) => void;
  onReply: (message: Message) => void;
  onPreviewDocument: (doc: any) => void;
  onPreviewImage: (img: any) => void;
}

const AVAILABLE_EMOJIS = ["👍", "❤️", "🔥", "🚀", "💡", "🙌", "😂"];

export function MessageItem({
  message,
  currentUser,
  onReact,
  onPin,
  onDelete,
  onReply,
  onPreviewDocument,
  onPreviewImage,
}: MessageItemProps) {
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  const isCurrentUser = message.senderId === currentUser?.id;
  const reactions = message.reactions || {};

  return (
    <div
      className={`group relative flex flex-col my-3 transition-colors ${
        message.isPinned ? "bg-indigo-950/20 p-2 rounded-2xl border border-indigo-500/20" : ""
      }`}
    >
      {/* Pinned banner indicator if pinned */}
      {message.isPinned && (
        <div className="flex items-center gap-1 text-[11px] text-indigo-400 mb-1 px-1 font-medium">
          <Pin className="w-3 h-3 rotate-45" />
          <span>Pinned message</span>
        </div>
      )}

      <div
        className={`flex items-end gap-2.5 ${
          isCurrentUser ? "flex-row-reverse" : "flex-row"
        }`}
      >
        {/* Author Avatar */}
        <div className="shrink-0 mb-1">
          <img
            src={message.sender?.avatar || "https://api.dicebear.com/7.x/avataaars/svg?seed=user"}
            alt={message.sender?.name || "User"}
            className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-700 shadow"
          />
        </div>

        {/* Message Bubble Container */}
        <div className={`max-w-[85%] sm:max-w-[70%] flex flex-col ${isCurrentUser ? "items-end" : "items-start"}`}>
          {/* Sender Name & Time */}
          <div className="flex items-center gap-2 mb-1 px-1 text-[11px] text-slate-400">
            <span className="font-semibold text-slate-300">
              {isCurrentUser ? "You" : message.sender?.name || "Partner"}
            </span>
            <span>{formatMessageTime(message.createdAt)}</span>
          </div>

          {/* Bubble Box */}
          <div
            className={`relative rounded-2xl px-4 py-3 text-sm shadow-md transition-all ${
              isCurrentUser
                ? "bg-indigo-600 text-white rounded-br-none shadow-indigo-900/30"
                : "bg-slate-800 text-slate-100 rounded-bl-none border border-slate-700/60 shadow-black/20"
            }`}
          >
            {/* 1. Voice Note Type */}
            {message.type === "voice" && message.mediaUrl && (
              <div className="py-1">
                <AudioWavePlayer
                  src={message.mediaUrl}
                  duration={message.mediaDuration}
                  waveform={message.mediaWaveform}
                  fileName={message.mediaName}
                  isCurrentUser={isCurrentUser}
                />
                {message.content && (
                  <p className="mt-2 text-xs opacity-90 leading-relaxed">{message.content}</p>
                )}
              </div>
            )}

            {/* 2. Image Attachment Type */}
            {message.type === "image" && message.mediaUrl && (
              <div className="space-y-2">
                <div
                  onClick={() =>
                    onPreviewImage({
                      imageUrl: message.mediaUrl,
                      imageName: message.mediaName,
                      imageSize: message.mediaSize,
                      caption: message.content,
                    })
                  }
                  className="rounded-xl overflow-hidden cursor-pointer group/img relative border border-white/10 max-h-72 max-w-sm"
                >
                  <img
                    src={message.mediaUrl}
                    alt={message.mediaName || "Image"}
                    className="w-full h-full object-cover transition-transform duration-200 group-hover/img:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white">
                    <Eye className="w-5 h-5" />
                    <span className="text-xs font-semibold">Click to Zoom</span>
                  </div>
                </div>
                {message.content && (
                  <p className="text-xs leading-relaxed opacity-95">{message.content}</p>
                )}
              </div>
            )}

            {/* 3. Document Attachment Type */}
            {message.type === "document" && (
              <div className="space-y-2">
                <div
                  className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                    isCurrentUser
                      ? "bg-indigo-700/70 border-indigo-400/30"
                      : "bg-slate-900/90 border-slate-700"
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="p-2 rounded-lg bg-white/10 text-white shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="truncate">
                      <div className="font-medium text-xs truncate max-w-[180px] sm:max-w-[240px]">
                        {message.mediaName || "Document.pdf"}
                      </div>
                      <div className="text-[10px] opacity-75">
                        {formatBytes(message.mediaSize)} • {message.mediaMime || "Document"}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() =>
                        onPreviewDocument({
                          fileName: message.mediaName,
                          fileUrl: message.mediaUrl,
                          fileSize: message.mediaSize,
                          mimeType: message.mediaMime,
                          description: message.content,
                          sender: message.sender,
                          createdAt: message.createdAt,
                        })
                      }
                      title="Preview Document"
                      className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition cursor-pointer text-xs"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                    {message.mediaUrl && (
                      <a
                        href={message.mediaUrl}
                        download={message.mediaName || "document"}
                        title="Download"
                        className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition cursor-pointer text-xs"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </div>

                {message.content && (
                  <p className="text-xs leading-relaxed opacity-95">{message.content}</p>
                )}
              </div>
            )}

            {/* 4. Code Snippet Type */}
            {message.type === "code" && (
              <div className="space-y-1.5 font-mono text-xs">
                <div className="flex items-center gap-1.5 text-[11px] opacity-80 pb-1 border-b border-white/10">
                  <Code className="w-3.5 h-3.5" />
                  <span>Code Snippet</span>
                </div>
                <pre className="bg-slate-950/80 p-3 rounded-lg overflow-x-auto text-[11px] leading-relaxed text-emerald-300">
                  <code>{message.content}</code>
                </pre>
              </div>
            )}

            {/* 5. Call Log Type */}
            {message.type === "call_log" && (
              <div className="flex items-center gap-2 text-xs py-1">
                <PhoneCall className="w-4 h-4 text-emerald-400" />
                <span>{message.content || "Completed Voice/Video Call"}</span>
              </div>
            )}

            {/* 6. Standard Text Message */}
            {message.type === "text" && (
              <p className="whitespace-pre-wrap leading-relaxed break-words">{message.content}</p>
            )}

            {/* Read status checkmarks */}
            {isCurrentUser && (
              <div className="flex justify-end mt-1 text-indigo-200">
                <CheckCheck className="w-3.5 h-3.5 opacity-80" />
              </div>
            )}
          </div>

          {/* Reactions Bar Below Bubble */}
          {Object.keys(reactions).length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1 px-1">
              {Object.entries(reactions).map(([emoji, uids]) => {
                const hasReacted = currentUser && uids.includes(currentUser.id);
                return (
                  <button
                    key={emoji}
                    onClick={() => onReact(message.id, emoji)}
                    className={`px-2 py-0.5 rounded-full text-xs flex items-center gap-1 transition cursor-pointer ${
                      hasReacted
                        ? "bg-indigo-500/30 border border-indigo-400/50 text-white"
                        : "bg-slate-800/80 border border-slate-700/60 text-slate-300 hover:bg-slate-700"
                    }`}
                  >
                    <span>{emoji}</span>
                    <span className="text-[10px] font-semibold">{uids.length}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Hover Action Toolbar */}
        <div
          className={`opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-slate-900 border border-slate-700/80 rounded-xl p-1 shadow-lg shrink-0 mb-2 ${
            isCurrentUser ? "flex-row-reverse" : "flex-row"
          }`}
        >
          {/* Reaction Emoji Trigger */}
          <div className="relative">
            <button
              onClick={() => setShowEmojiPicker((prev) => !prev)}
              className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
              title="Add Reaction"
            >
              <Smile className="w-3.5 h-3.5" />
            </button>

            {/* Quick Emoji Picker Floating Panel */}
            {showEmojiPicker && (
              <div className="absolute bottom-full mb-1 left-0 z-30 flex items-center gap-1 bg-slate-800 border border-slate-700 rounded-xl p-1.5 shadow-2xl animate-in zoom-in-95">
                {AVAILABLE_EMOJIS.map((em) => (
                  <button
                    key={em}
                    onClick={() => {
                      onReact(message.id, em);
                      setShowEmojiPicker(false);
                    }}
                    className="p-1 text-base hover:scale-125 transition-transform cursor-pointer"
                  >
                    {em}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={() => onReply(message)}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
            title="Reply"
          >
            <Reply className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onPin(message.id)}
            className={`p-1 rounded hover:bg-slate-800 transition cursor-pointer ${
              message.isPinned ? "text-indigo-400" : "text-slate-400 hover:text-white"
            }`}
            title={message.isPinned ? "Unpin Message" : "Pin Message"}
          >
            <Pin className="w-3.5 h-3.5" />
          </button>

          {isCurrentUser && (
            <button
              onClick={() => onDelete(message.id)}
              className="p-1 rounded hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition cursor-pointer"
              title="Delete Message"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
