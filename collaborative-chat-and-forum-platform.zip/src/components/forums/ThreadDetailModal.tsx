"use client";

import React, { useState, useEffect } from "react";
import {
  MessageSquare,
  Heart,
  Pin,
  BarChart3,
  Send,
  Sparkles,
  X,
  CheckCircle2,
  Calendar,
  Share2,
} from "lucide-react";
import { ForumThread, ForumReply, User } from "@/types";
import { useUser } from "@/context/UserContext";
import { formatTimeAgo } from "@/lib/utils";

interface ThreadDetailModalProps {
  isOpen: boolean;
  threadId: number | null;
  onClose: () => void;
  onThreadUpdated: () => void;
}

export function ThreadDetailModal({
  isOpen,
  threadId,
  onClose,
  onThreadUpdated,
}: ThreadDetailModalProps) {
  const { currentUser } = useUser();
  const [thread, setThread] = useState<ForumThread | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [replyContent, setReplyContent] = useState("");
  const [isSubmittingReply, setIsSubmittingReply] = useState(false);
  const [isLiked, setIsLiked] = useState(false);

  const fetchThreadDetails = async () => {
    if (!threadId) return;
    try {
      const res = await fetch(`/api/forums/threads/${threadId}`);
      const data = await res.json();
      if (data.success && data.thread) {
        setThread(data.thread);
      }
    } catch (err) {
      console.error("Failed to load thread details:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && threadId) {
      setIsLoading(true);
      fetchThreadDetails();
    }
  }, [isOpen, threadId]);

  const handleVotePoll = async (optionId: number) => {
    if (!currentUser || !threadId) return;
    try {
      const res = await fetch(`/api/forums/threads/${threadId}/poll-vote`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          optionId,
        }),
      });
      const data = await res.json();
      if (data.success && data.pollData) {
        setThread((prev) => (prev ? { ...prev, pollData: data.pollData } : null));
        onThreadUpdated();
      }
    } catch (err) {
      console.error("Poll vote failed:", err);
    }
  };

  const handleToggleLike = async () => {
    if (!currentUser || !threadId) return;
    try {
      const res = await fetch(`/api/forums/threads/${threadId}/like`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          targetType: "thread",
        }),
      });
      const data = await res.json();
      if (data.success) {
        setIsLiked(data.liked);
        setThread((prev) =>
          prev
            ? {
                ...prev,
                likesCount: data.liked ? prev.likesCount + 1 : Math.max(0, prev.likesCount - 1),
              }
            : null
        );
        onThreadUpdated();
      }
    } catch (err) {
      console.error("Like failed:", err);
    }
  };

  const handleSubmitReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !threadId || !replyContent.trim()) return;

    setIsSubmittingReply(true);
    try {
      const res = await fetch(`/api/forums/threads/${threadId}/replies`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authorId: currentUser.id,
          content: replyContent.trim(),
        }),
      });

      const data = await res.json();
      if (data.success && data.reply) {
        setReplyContent("");
        setThread((prev) =>
          prev
            ? {
                ...prev,
                repliesCount: prev.repliesCount + 1,
                replies: [...(prev.replies || []), data.reply],
              }
            : null
        );
        onThreadUpdated();
      }
    } catch (err) {
      console.error("Submit reply failed:", err);
    } finally {
      setIsSubmittingReply(false);
    }
  };

  if (!isOpen || !threadId) return null;

  const poll = thread?.pollData;
  const totalPollVotes = poll?.options
    ? poll.options.reduce((sum, opt) => sum + (opt.votes?.length || 0), 0)
    : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden relative">
        {/* Top Header */}
        <div className="p-5 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              {thread?.forum?.title || "Forum Discussion"}
            </span>
            {thread?.isPinned && (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/20 flex items-center gap-1">
                <Pin className="w-3 h-3" />
                <span>Pinned Topic</span>
              </span>
            )}
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scroll Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {isLoading || !thread ? (
            <div className="flex flex-col items-center justify-center p-12 text-slate-400">
              <Sparkles className="w-6 h-6 animate-spin text-indigo-400 mb-2" />
              <span className="text-xs">Loading forum discussion...</span>
            </div>
          ) : (
            <>
              {/* Thread Main Card */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-6 relative">
                <h2 className="text-2xl font-extrabold text-white leading-tight mb-4">
                  {thread.title}
                </h2>

                <div className="text-sm text-slate-200 whitespace-pre-wrap leading-relaxed space-y-3 font-sans">
                  {thread.content}
                </div>

                {/* Interactive Poll Section if present */}
                {poll && poll.options && (
                  <div className="mt-6 bg-slate-900 border border-indigo-500/30 rounded-2xl p-5 shadow-lg">
                    <div className="flex items-center gap-2 text-xs font-bold text-indigo-300 mb-3">
                      <BarChart3 className="w-4 h-4" />
                      <span>COMMUNITY DECISION POLL</span>
                    </div>

                    <h4 className="text-sm font-semibold text-white mb-4">{poll.question}</h4>

                    <div className="space-y-3">
                      {poll.options.map((opt) => {
                        const votesCount = opt.votes?.length || 0;
                        const pct =
                          totalPollVotes > 0 ? Math.round((votesCount / totalPollVotes) * 100) : 0;
                        const hasUserVoted = currentUser && opt.votes?.includes(currentUser.id);

                        return (
                          <div
                            key={opt.id}
                            onClick={() => handleVotePoll(opt.id)}
                            className={`p-3 rounded-xl border transition-all cursor-pointer relative overflow-hidden group ${
                              hasUserVoted
                                ? "bg-indigo-950/50 border-indigo-500/60 shadow"
                                : "bg-slate-950/70 border-slate-800 hover:border-slate-700"
                            }`}
                          >
                            {/* Progress bar background fill */}
                            <div
                              style={{ width: `${pct}%` }}
                              className={`absolute inset-y-0 left-0 transition-all duration-500 pointer-events-none opacity-25 ${
                                hasUserVoted ? "bg-indigo-500" : "bg-slate-600"
                              }`}
                            />

                            <div className="relative z-10 flex items-center justify-between text-xs">
                              <div className="flex items-center gap-2">
                                <div
                                  className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                                    hasUserVoted
                                      ? "border-indigo-400 bg-indigo-500 text-white"
                                      : "border-slate-600"
                                  }`}
                                >
                                  {hasUserVoted && <span className="text-[10px]">✓</span>}
                                </div>
                                <span className="font-medium text-slate-200">{opt.text}</span>
                              </div>

                              <div className="flex items-center gap-2 font-mono text-slate-400">
                                <span>{votesCount} votes</span>
                                <span className="font-bold text-white">({pct}%)</span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <div className="mt-3 text-[11px] text-slate-500 text-right font-mono">
                      Total {totalPollVotes} votes cast
                    </div>
                  </div>
                )}

                {/* Tags */}
                {thread.tags && thread.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-4">
                    {thread.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-0.5 rounded-lg bg-slate-800 text-indigo-300 border border-indigo-500/20 text-xs font-medium"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                )}

                {/* Bottom Meta & Like button */}
                <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-2">
                    {thread.author && (
                      <img
                        src={thread.author.avatar}
                        alt={thread.author.name}
                        className="w-6 h-6 rounded-full object-cover ring-1 ring-indigo-500/40"
                      />
                    )}
                    <span className="text-slate-200 font-medium">{thread.author?.name}</span>
                    <span>•</span>
                    <span>{formatTimeAgo(thread.createdAt)}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleToggleLike}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                        isLiked
                          ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                          : "bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700"
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${isLiked ? "fill-current" : ""}`} />
                      <span>{thread.likesCount} Likes</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Replies Stream Header */}
              <div className="flex items-center justify-between pt-2">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-indigo-400" />
                  <span>{thread.replies?.length || 0} Replies & Discussions</span>
                </h3>
              </div>

              {/* Replies List */}
              <div className="space-y-3">
                {thread.replies && thread.replies.length > 0 ? (
                  thread.replies.map((rep) => (
                    <div
                      key={rep.id}
                      className="bg-slate-950/40 border border-slate-800 rounded-2xl p-5 space-y-2"
                    >
                      <div className="flex items-center justify-between text-xs text-slate-400">
                        <div className="flex items-center gap-2">
                          {rep.author && (
                            <img
                              src={rep.author.avatar}
                              alt={rep.author.name}
                              className="w-6 h-6 rounded-full object-cover ring-1 ring-slate-700"
                            />
                          )}
                          <span className="text-slate-200 font-semibold">{rep.author?.name}</span>
                          <span>•</span>
                          <span>{formatTimeAgo(rep.createdAt)}</span>
                        </div>
                      </div>

                      <div className="text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
                        {rep.content}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-6 text-center bg-slate-950/30 border border-slate-800/80 rounded-2xl text-slate-400 text-xs">
                    No replies yet. Join the conversation and share your perspective!
                  </div>
                )}
              </div>

              {/* Submit Reply Box */}
              <div className="pt-2">
                <form onSubmit={handleSubmitReply} className="space-y-3">
                  <textarea
                    rows={3}
                    required
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    placeholder="Write a reply or comment to this discussion..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                  />

                  <div className="flex items-center justify-end">
                    <button
                      type="submit"
                      disabled={isSubmittingReply || !replyContent.trim()}
                      className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isSubmittingReply ? "Posting..." : "Post Reply (+5 Rep)"}</span>
                    </button>
                  </div>
                </form>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
