"use client";

import React, { useState, useEffect } from "react";
import {
  MessageSquare,
  Sparkles,
  Plus,
  Search,
  Pin,
  Heart,
  BarChart3,
  Code,
  Lightbulb,
  Coffee,
  ArrowLeft,
  Users,
  ShieldCheck,
  ChevronRight,
} from "lucide-react";
import { ForumCategory, ForumThread } from "@/types";
import { useUser } from "@/context/UserContext";
import { formatTimeAgo } from "@/lib/utils";
import { ThreadDetailModal } from "./ThreadDetailModal";

export function ForumsSection() {
  const { currentUser } = useUser();
  const [forums, setForums] = useState<ForumCategory[]>([]);
  const [selectedForum, setSelectedForum] = useState<ForumCategory | null>(null);
  const [threads, setThreads] = useState<ForumThread[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoadingForums, setIsLoadingForums] = useState(true);
  const [isLoadingThreads, setIsLoadingThreads] = useState(false);

  // Modals
  const [selectedThreadId, setSelectedThreadId] = useState<number | null>(null);
  const [showCreateForumModal, setShowCreateForumModal] = useState(false);
  const [showCreateThreadModal, setShowCreateThreadModal] = useState(false);

  // New Forum Form
  const [newForumTitle, setNewForumTitle] = useState("");
  const [newForumDesc, setNewForumDesc] = useState("");
  const [newForumIcon, setNewForumIcon] = useState("message-square");
  const [newForumColor, setNewForumColor] = useState("indigo");
  const [isSubmittingForum, setIsSubmittingForum] = useState(false);

  // New Thread Form
  const [newThreadTitle, setNewThreadTitle] = useState("");
  const [newThreadContent, setNewThreadContent] = useState("");
  const [newThreadTags, setNewThreadTags] = useState("RFC, Discussion");
  const [newThreadHasPoll, setNewThreadHasPoll] = useState(false);
  const [newPollQuestion, setNewPollQuestion] = useState("");
  const [newPollOption1, setNewPollOption1] = useState("");
  const [newPollOption2, setNewPollOption2] = useState("");
  const [newPollOption3, setNewPollOption3] = useState("");
  const [isSubmittingThread, setIsSubmittingThread] = useState(false);

  const fetchForums = async () => {
    try {
      const res = await fetch("/api/forums");
      const data = await res.json();
      if (data.success && Array.isArray(data.forums)) {
        setForums(data.forums);
      }
    } catch (err) {
      console.error("Failed to load forums:", err);
    } finally {
      setIsLoadingForums(false);
    }
  };

  const fetchThreadsForForum = async (forumId: number) => {
    setIsLoadingThreads(true);
    try {
      let url = `/api/forums/${forumId}`;
      if (searchQuery) url += `?query=${encodeURIComponent(searchQuery)}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.success && Array.isArray(data.threads)) {
        setThreads(data.threads);
      }
    } catch (err) {
      console.error("Failed to load threads:", err);
    } finally {
      setIsLoadingThreads(false);
    }
  };

  useEffect(() => {
    fetchForums();
  }, []);

  useEffect(() => {
    if (selectedForum) {
      fetchThreadsForForum(selectedForum.id);
    }
  }, [selectedForum, searchQuery]);

  const handleCreateForum = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !newForumTitle.trim() || !newForumDesc.trim()) return;

    setIsSubmittingForum(true);
    try {
      const res = await fetch("/api/forums", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newForumTitle.trim(),
          description: newForumDesc.trim(),
          icon: newForumIcon,
          color: newForumColor,
          createdById: currentUser.id,
        }),
      });

      const data = await res.json();
      if (data.success && data.forum) {
        setForums((prev) => [data.forum, ...prev]);
        setShowCreateForumModal(false);
        setNewForumTitle("");
        setNewForumDesc("");
      }
    } catch (err) {
      console.error("Create forum failed:", err);
    } finally {
      setIsSubmittingForum(false);
    }
  };

  const handleCreateThread = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !selectedForum || !newThreadTitle.trim() || !newThreadContent.trim())
      return;

    setIsSubmittingThread(true);
    try {
      const parsedTags = newThreadTags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean);

      let pollData = null;
      if (newThreadHasPoll && newPollQuestion.trim()) {
        const options = [
          newPollOption1.trim() ? { id: 1, text: newPollOption1.trim(), votes: [] } : null,
          newPollOption2.trim() ? { id: 2, text: newPollOption2.trim(), votes: [] } : null,
          newPollOption3.trim() ? { id: 3, text: newPollOption3.trim(), votes: [] } : null,
        ].filter(Boolean);

        if (options.length >= 2) {
          pollData = {
            question: newPollQuestion.trim(),
            options,
          };
        }
      }

      const res = await fetch(`/api/forums/${selectedForum.id}/threads`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authorId: currentUser.id,
          title: newThreadTitle.trim(),
          content: newThreadContent.trim(),
          tags: parsedTags,
          hasPoll: !!pollData,
          pollData,
        }),
      });

      const data = await res.json();
      if (data.success && data.thread) {
        setThreads((prev) => [data.thread, ...prev]);
        setShowCreateThreadModal(false);
        setNewThreadTitle("");
        setNewThreadContent("");
        setNewThreadHasPoll(false);
        setNewPollQuestion("");
        setNewPollOption1("");
        setNewPollOption2("");
        setNewPollOption3("");
      }
    } catch (err) {
      console.error("Create thread failed:", err);
    } finally {
      setIsSubmittingThread(false);
    }
  };

  const getForumIcon = (iconName: string) => {
    switch (iconName) {
      case "code":
        return <Code className="w-5 h-5 text-indigo-400" />;
      case "sparkles":
        return <Sparkles className="w-5 h-5 text-purple-400" />;
      case "lightbulb":
        return <Lightbulb className="w-5 h-5 text-amber-400" />;
      case "coffee":
        return <Coffee className="w-5 h-5 text-emerald-400" />;
      default:
        return <MessageSquare className="w-5 h-5 text-indigo-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-md relative overflow-hidden shadow-xl">
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-xs font-semibold text-indigo-400 mb-2">
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Collaborative Community Forums</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Discussion Hub & Channels
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Create custom forums, propose RFCs, run community polls, and engage in threaded engineering discussions.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
            {selectedForum ? (
              <button
                onClick={() => setShowCreateThreadModal(true)}
                className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Start Discussion (+15 Rep)</span>
              </button>
            ) : (
              <button
                onClick={() => setShowCreateForumModal(true)}
                className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Create New Forum (+20 Rep)</span>
              </button>
            )}
          </div>
        </div>

        {/* Selected Forum Breadcrumb Navigation */}
        {selectedForum && (
          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between gap-4">
            <button
              onClick={() => setSelectedForum(null)}
              className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to All Forum Categories</span>
            </button>

            <div className="relative w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search threads..."
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl py-1.5 pl-8 pr-3 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        )}
      </div>

      {/* VIEW 1: Categories Grid */}
      {!selectedForum ? (
        <div>
          <div className="flex items-center justify-between mb-4 px-1">
            <h3 className="text-base font-bold text-white">All Forum Channels</h3>
            <span className="text-xs text-slate-400">{forums.length} Categories Available</span>
          </div>

          {isLoadingForums ? (
            <div className="flex flex-col items-center justify-center p-12 text-slate-400">
              <Sparkles className="w-6 h-6 animate-spin text-indigo-400 mb-2" />
              <span className="text-xs">Loading forum channels...</span>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {forums.map((forum) => (
                <div
                  key={forum.id}
                  onClick={() => setSelectedForum(forum)}
                  className="bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 rounded-3xl p-6 transition shadow-lg hover:shadow-2xl cursor-pointer group flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/60 shrink-0 group-hover:scale-105 transition-transform">
                        {getForumIcon(forum.icon)}
                      </div>
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                        {forum.threadsCount || 0} Discussions
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-white group-hover:text-indigo-300 transition-colors">
                      {forum.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                      {forum.description}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                    <div className="flex items-center gap-2">
                      {forum.createdBy && (
                        <img
                          src={forum.createdBy.avatar}
                          alt={forum.createdBy.name}
                          className="w-5 h-5 rounded-full object-cover ring-1 ring-slate-700"
                        />
                      )}
                      <span className="text-slate-300">
                        Created by {forum.createdBy?.name || "Member"}
                      </span>
                    </div>

                    <span className="text-indigo-400 group-hover:translate-x-1 transition-transform flex items-center gap-1 font-semibold">
                      <span>Explore</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* VIEW 2: Inside Category Threads */
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-base font-bold text-white">
              Discussions in {selectedForum.title}
            </h3>
            <span className="text-xs text-slate-400">{threads.length} Threads</span>
          </div>

          {isLoadingThreads ? (
            <div className="flex flex-col items-center justify-center p-12 text-slate-400">
              <Sparkles className="w-6 h-6 animate-spin text-indigo-400 mb-2" />
              <span className="text-xs">Loading discussions...</span>
            </div>
          ) : threads.length === 0 ? (
            <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-12 text-center text-slate-400">
              <MessageSquare className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-slate-300">No discussions yet</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Be the first to start a conversation or proposal in this forum!
              </p>
            </div>
          ) : (
            threads.map((thread) => (
              <div
                key={thread.id}
                onClick={() => setSelectedThreadId(thread.id)}
                className={`bg-slate-900/90 border rounded-2xl p-5 sm:p-6 transition hover:shadow-xl cursor-pointer group ${
                  thread.isPinned
                    ? "border-amber-500/30 hover:border-amber-500/60 bg-amber-950/10"
                    : "border-slate-800 hover:border-indigo-500/50"
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      {thread.isPinned && (
                        <span className="px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/20 flex items-center gap-1">
                          <Pin className="w-3 h-3" />
                          <span>Pinned Topic</span>
                        </span>
                      )}
                      {thread.hasPoll && (
                        <span className="px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 flex items-center gap-1">
                          <BarChart3 className="w-3 h-3" />
                          <span>Poll Active</span>
                        </span>
                      )}
                    </div>

                    <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors leading-snug">
                      {thread.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                      {thread.content}
                    </p>

                    {/* Tags & Meta */}
                    <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <div className="flex flex-wrap gap-1.5">
                        {thread.tags &&
                          thread.tags.map((tag, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px]"
                            >
                              #{tag}
                            </span>
                          ))}
                      </div>

                      <div className="flex items-center gap-4 text-slate-400">
                        <div className="flex items-center gap-1.5 text-slate-300">
                          {thread.author && (
                            <img
                              src={thread.author.avatar}
                              alt={thread.author.name}
                              className="w-5 h-5 rounded-full object-cover ring-1 ring-slate-700"
                            />
                          )}
                          <span>{thread.author?.name}</span>
                          <span>•</span>
                          <span>{formatTimeAgo(thread.createdAt)}</span>
                        </div>

                        <div className="flex items-center gap-3 font-mono text-[11px]">
                          <span className="flex items-center gap-1">
                            <Heart className="w-3.5 h-3.5 text-rose-400" />
                            <span>{thread.likesCount}</span>
                          </span>
                          <span className="flex items-center gap-1">
                            <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
                            <span>{thread.repliesCount}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Modal 1: Create New Forum */}
      {showCreateForumModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-lg p-6 shadow-2xl relative">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-white">Create New Forum Channel</h3>
              <button
                onClick={() => setShowCreateForumModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateForum} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Forum Title
                </label>
                <input
                  type="text"
                  required
                  value={newForumTitle}
                  onChange={(e) => setNewForumTitle(e.target.value)}
                  placeholder="e.g. AI Integrations & Workflows"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Channel Description
                </label>
                <textarea
                  rows={2}
                  required
                  value={newForumDesc}
                  onChange={(e) => setNewForumDesc(e.target.value)}
                  placeholder="What topics and discussions belong in this forum?"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Channel Icon
                  </label>
                  <select
                    value={newForumIcon}
                    onChange={(e) => setNewForumIcon(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="code">💻 Code & Engineering</option>
                    <option value="sparkles">✨ UX & Design</option>
                    <option value="lightbulb">💡 Brainstorming</option>
                    <option value="coffee">☕ General & Watercooler</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Theme Color
                  </label>
                  <select
                    value={newForumColor}
                    onChange={(e) => setNewForumColor(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="indigo">Indigo Glow</option>
                    <option value="purple">Purple Modern</option>
                    <option value="emerald">Emerald Green</option>
                    <option value="amber">Amber Warm</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateForumModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingForum || !newForumTitle.trim()}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition cursor-pointer"
                >
                  {isSubmittingForum ? "Creating..." : "Create Channel (+20 Rep)"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Create New Discussion Thread */}
      {showCreateThreadModal && selectedForum && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-white">
                Start Discussion in {selectedForum.title}
              </h3>
              <button
                onClick={() => setShowCreateThreadModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateThread} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Discussion Title
                </label>
                <input
                  type="text"
                  required
                  value={newThreadTitle}
                  onChange={(e) => setNewThreadTitle(e.target.value)}
                  placeholder="e.g. RFC: Distributed State Replication Strategy"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={newThreadTags}
                  onChange={(e) => setNewThreadTags(e.target.value)}
                  placeholder="Architecture, Postgres, v2"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Content & Proposal
                </label>
                <textarea
                  rows={4}
                  required
                  value={newThreadContent}
                  onChange={(e) => setNewThreadContent(e.target.value)}
                  placeholder="Share details, context, and discussion points..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Optional Poll Section */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newThreadHasPoll}
                    onChange={(e) => setNewThreadHasPoll(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-0 cursor-pointer"
                  />
                  <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                    <BarChart3 className="w-3.5 h-3.5" />
                    <span>Include a Community Decision Poll</span>
                  </span>
                </label>

                {newThreadHasPoll && (
                  <div className="space-y-2.5 pt-2 border-t border-slate-800/80 animate-in fade-in">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">
                        Poll Question
                      </label>
                      <input
                        type="text"
                        value={newPollQuestion}
                        onChange={(e) => setNewPollQuestion(e.target.value)}
                        placeholder="e.g. Which API protocol do you recommend?"
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-600"
                      />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={newPollOption1}
                        onChange={(e) => setNewPollOption1(e.target.value)}
                        placeholder="Option 1"
                        className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-600"
                      />
                      <input
                        type="text"
                        value={newPollOption2}
                        onChange={(e) => setNewPollOption2(e.target.value)}
                        placeholder="Option 2"
                        className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-600"
                      />
                      <input
                        type="text"
                        value={newPollOption3}
                        onChange={(e) => setNewPollOption3(e.target.value)}
                        placeholder="Option 3 (Optional)"
                        className="sm:col-span-2 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-600"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateThreadModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingThread || !newThreadTitle.trim() || !newThreadContent.trim()}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition cursor-pointer"
                >
                  {isSubmittingThread ? "Publishing..." : "Start Discussion (+15 Rep)"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 3: Thread Detailed Discussion View */}
      <ThreadDetailModal
        isOpen={!!selectedThreadId}
        threadId={selectedThreadId}
        onClose={() => setSelectedThreadId(null)}
        onThreadUpdated={() => {
          if (selectedForum) fetchThreadsForForum(selectedForum.id);
        }}
      />
    </div>
  );
}
