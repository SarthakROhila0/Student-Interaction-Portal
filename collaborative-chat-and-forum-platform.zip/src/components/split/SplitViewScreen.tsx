"use client";

import React, { useState } from "react";
import { useUser } from "@/context/UserContext";
import { ChatSection } from "@/components/chat/ChatSection";
import { VaultSection } from "@/components/vault/VaultSection";
import { QnaSection } from "@/components/qna/QnaSection";
import { ForumsSection } from "@/components/forums/ForumsSection";
import { MessageSquare, Folder, HelpCircle, Columns, Sparkles, X } from "lucide-react";

export function SplitViewScreen() {
  const { users, setSplitScreenMode } = useUser();
  const alex = users.find((u) => u.id === "user_alex") || users[0];
  const elena = users.find((u) => u.id === "user_elena") || users[1] || users[0];

  const [leftTab, setLeftTab] = useState<"chat" | "vault" | "qna" | "forums">("chat");
  const [rightTab, setRightTab] = useState<"chat" | "vault" | "qna" | "forums">("chat");

  return (
    <div className="space-y-4">
      {/* Top Split View Banner Header */}
      <div className="bg-indigo-950/60 border border-indigo-500/40 rounded-2xl p-4 flex items-center justify-between backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-300">
            <Columns className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">Dual-User Interactive Simulator Mode</h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono animate-pulse">
                ● Live 2-Way Sync Active
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Left Pane is Alex Rivera (Lead Architect) • Right Pane is Elena Chen (Product Lead). Actions on either side update seamlessly.
            </p>
          </div>
        </div>

        <button
          onClick={() => setSplitScreenMode(false)}
          className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
          <span>Exit Split View</span>
        </button>
      </div>

      {/* 2-Column Split Panes Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 min-h-[750px]">
        {/* LEFT PANE: Alex Rivera */}
        <div className="flex flex-col bg-slate-900/90 border border-indigo-500/40 rounded-3xl overflow-hidden shadow-2xl">
          {/* Persona Header Pill */}
          <div className="px-5 py-3 bg-indigo-950/80 border-b border-indigo-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <img
                src={alex?.avatar}
                alt={alex?.name}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-indigo-400"
              />
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>{alex?.name}</span>
                  <span className="text-[10px] px-2 py-0.2 rounded-full bg-indigo-500/20 text-indigo-300">
                    Lead Architect
                  </span>
                </div>
                <div className="text-[10px] text-slate-400">User 1 Persona</div>
              </div>
            </div>

            {/* Pane Navigation Tabs */}
            <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setLeftTab("chat")}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer ${
                  leftTab === "chat" ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                Chat
              </button>
              <button
                onClick={() => setLeftTab("vault")}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer ${
                  leftTab === "vault" ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                Vault
              </button>
              <button
                onClick={() => setLeftTab("qna")}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer ${
                  leftTab === "qna" ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                Q&A
              </button>
            </div>
          </div>

          {/* Left Content Area */}
          <div className="flex-1 p-3 overflow-y-auto">
            {leftTab === "chat" && (
              <div className="h-[620px]">
                <ChatSection forcedCurrentUser={alex} forcedPartnerUser={elena} compactMode={true} />
              </div>
            )}
            {leftTab === "vault" && <VaultSection />}
            {leftTab === "qna" && <QnaSection />}
          </div>
        </div>

        {/* RIGHT PANE: Elena Chen */}
        <div className="flex flex-col bg-slate-900/90 border border-purple-500/40 rounded-3xl overflow-hidden shadow-2xl">
          {/* Persona Header Pill */}
          <div className="px-5 py-3 bg-purple-950/80 border-b border-purple-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <img
                src={elena?.avatar}
                alt={elena?.name}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-purple-400"
              />
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>{elena?.name}</span>
                  <span className="text-[10px] px-2 py-0.2 rounded-full bg-purple-500/20 text-purple-300">
                    Product Lead
                  </span>
                </div>
                <div className="text-[10px] text-slate-400">User 2 Persona</div>
              </div>
            </div>

            {/* Pane Navigation Tabs */}
            <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setRightTab("chat")}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer ${
                  rightTab === "chat" ? "bg-purple-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                Chat
              </button>
              <button
                onClick={() => setRightTab("vault")}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer ${
                  rightTab === "vault" ? "bg-purple-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                Vault
              </button>
              <button
                onClick={() => setRightTab("qna")}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer ${
                  rightTab === "qna" ? "bg-purple-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                Q&A
              </button>
            </div>
          </div>

          {/* Right Content Area */}
          <div className="flex-1 p-3 overflow-y-auto">
            {rightTab === "chat" && (
              <div className="h-[620px]">
                <ChatSection forcedCurrentUser={elena} forcedPartnerUser={alex} compactMode={true} />
              </div>
            )}
            {rightTab === "vault" && <VaultSection />}
            {rightTab === "qna" && <QnaSection />}
          </div>
        </div>
      </div>
    </div>
  );
}
