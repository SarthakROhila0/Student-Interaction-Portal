"use client";

import React, { useState, useEffect } from "react";
import {
  FileCode,
  Save,
  Sparkles,
  CheckCircle2,
  Edit3,
  Eye,
  Clock,
  User as UserIcon,
} from "lucide-react";
import { useUser } from "@/context/UserContext";
import { formatTimeAgo } from "@/lib/utils";

export function ScratchpadSection() {
  const { currentUser } = useUser();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [updatedBy, setUpdatedBy] = useState<any>(null);
  const [updatedAt, setUpdatedAt] = useState<string>("");
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<"edit" | "preview">("edit");
  const [isLoading, setIsLoading] = useState(true);

  const fetchNotes = async () => {
    try {
      const res = await fetch("/api/notes");
      const data = await res.json();
      if (data.success && data.note) {
        setTitle(data.note.title);
        setContent(data.note.content);
        setUpdatedBy(data.note.updatedBy);
        setUpdatedAt(data.note.updatedAt);
      }
    } catch (err) {
      console.error("Failed to load notes:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  const handleSave = async () => {
    if (!currentUser) return;
    setIsSaving(true);
    try {
      const res = await fetch("/api/notes", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          content,
          updatedById: currentUser.id,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSaveSuccess(true);
        setUpdatedBy(currentUser);
        setUpdatedAt(new Date().toISOString());
        setTimeout(() => setSaveSuccess(false), 2500);
      }
    } catch (err) {
      console.error("Failed to save note:", err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-md relative overflow-hidden shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400 mb-2">
              <FileCode className="w-3.5 h-3.5" />
              <span>Real-Time Collaborative Scratchpad</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Shared Whiteboard & Sprint Notes
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Collaborative scratchpad for task checklists, sprint notes, and architectural contracts between Alex & Elena.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition cursor-pointer"
            >
              {saveSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>Saved to Cloud</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>{isSaving ? "Syncing..." : "Save Scratchpad"}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Editor & Preview Workspace */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Scratchpad Document Title..."
            className="text-lg font-bold text-white bg-transparent border-none focus:outline-none flex-1 placeholder:text-slate-600"
          />

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab("edit")}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                activeTab === "edit"
                  ? "bg-indigo-600 text-white shadow"
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Editor</span>
            </button>
            <button
              onClick={() => setActiveTab("preview")}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                activeTab === "preview"
                  ? "bg-indigo-600 text-white shadow"
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Markdown Preview</span>
            </button>
          </div>
        </div>

        {/* Text Area / Preview */}
        {activeTab === "edit" ? (
          <textarea
            rows={16}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Write markdown notes, checklist items, API schemas..."
            className="w-full bg-slate-950/80 border border-slate-800/80 rounded-2xl p-5 text-sm font-mono text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500 leading-relaxed resize-y"
          />
        ) : (
          <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-6 min-h-[380px] font-sans text-sm text-slate-200 whitespace-pre-wrap leading-relaxed space-y-3">
            {content || "No content to preview. Switch to edit mode to add notes."}
          </div>
        )}

        {/* Footer Meta */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-3 border-t border-slate-800/80">
          <div className="flex items-center gap-2">
            {updatedBy ? (
              <div className="flex items-center gap-1.5">
                <img
                  src={updatedBy.avatar}
                  alt={updatedBy.name}
                  className="w-5 h-5 rounded-full object-cover ring-1 ring-indigo-500/40"
                />
                <span className="text-slate-300 font-medium">Last updated by {updatedBy.name}</span>
              </div>
            ) : (
              <span className="text-slate-500">Shared Scratchpad</span>
            )}
            {updatedAt && (
              <>
                <span>•</span>
                <span>{formatTimeAgo(updatedAt)}</span>
              </>
            )}
          </div>

          <span className="text-slate-500 font-mono text-[11px]">
            {content.length} characters • {content.split(/\s+/).filter(Boolean).length} words
          </span>
        </div>
      </div>
    </div>
  );
}
