"use client";

import React from "react";
import { FileText, Download, ExternalLink, X, Tag, User, Calendar, HardDrive } from "lucide-react";
import { formatBytes, formatTimeAgo } from "@/lib/utils";

interface DocumentViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: {
    fileName: string;
    fileUrl: string;
    fileSize?: number | null;
    mimeType?: string | null;
    sender?: any;
    description?: string;
    tags?: string[];
    createdAt?: string;
  } | null;
}

export function DocumentViewerModal({
  isOpen,
  onClose,
  document,
}: DocumentViewerModalProps) {
  if (!isOpen || !document) return null;

  const isPdf = document.mimeType?.includes("pdf") || document.fileName.toLowerCase().endsWith(".pdf");
  const isCodeOrText =
    document.mimeType?.includes("text") ||
    document.fileName.endsWith(".ts") ||
    document.fileName.endsWith(".js") ||
    document.fileName.endsWith(".json") ||
    document.fileName.endsWith(".md");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Top Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="truncate">
              <h3 className="text-base font-semibold text-white truncate">{document.fileName}</h3>
              <p className="text-xs text-slate-400 flex items-center gap-2">
                <span>{formatBytes(document.fileSize)}</span>
                <span>•</span>
                <span>{document.mimeType || "Document file"}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <a
              href={document.fileUrl}
              download={document.fileName}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium flex items-center gap-1.5 transition shadow cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </a>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Viewer Body */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-950/40">
          {/* Main Preview Container */}
          <div className="md:col-span-2 bg-slate-900/90 border border-slate-800 rounded-xl p-6 min-h-[360px] flex flex-col justify-between shadow-inner">
            {isPdf ? (
              <div className="flex flex-col items-center justify-center text-center my-auto p-6">
                <div className="w-16 h-16 rounded-2xl bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center mb-4">
                  <FileText className="w-8 h-8" />
                </div>
                <h4 className="text-lg font-semibold text-white mb-1">{document.fileName}</h4>
                <p className="text-xs text-slate-400 max-w-md mb-6">
                  PDF Architecture Specification & Engineering Guidelines. Interactive document reader enabled.
                </p>
                <div className="w-full bg-slate-950 border border-slate-800 rounded-lg p-4 text-left font-mono text-xs text-slate-300 space-y-2 mb-4">
                  <div className="text-indigo-400 font-bold"># Abstract: Multi-User Sync Architecture v2.4</div>
                  <div className="text-slate-400 text-[11px]">
                    1. High Concurrency Real-Time Polling Engine<br />
                    2. WebAudio PCM Frequency Buffer Serializer<br />
                    3. PostgreSQL Composite Partitioning & Indexes<br />
                    4. End-to-End Persona Verification Contracts
                  </div>
                </div>
                <a
                  href={document.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 underline font-medium"
                >
                  <span>Open raw document in new browser tab</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            ) : (
              <div className="font-mono text-xs text-slate-300 whitespace-pre-wrap leading-relaxed overflow-x-auto">
                <div className="text-indigo-400 font-bold mb-3">
                  // {document.fileName} — Shared Workspace Document
                </div>
                {document.description ||
                  `/**\n * Technical document shared in direct 2-user portal\n * File Name: ${document.fileName}\n * Category: Technical Architecture\n */\n\nexport interface WorkspaceSyncConfig {\n  heartbeatIntervalMs: 2500;\n  maxUploadSizeBytes: 52428800; // 50MB\n  enableWaveformCache: true;\n}`}
              </div>
            )}
          </div>

          {/* Document Metadata Sidebar */}
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                File Details
              </h4>

              <div className="flex items-center gap-2 text-xs text-slate-300">
                <HardDrive className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>Size: {formatBytes(document.fileSize)}</span>
              </div>

              {document.createdAt && (
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <Calendar className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span>Shared: {formatTimeAgo(document.createdAt)}</span>
                </div>
              )}

              {document.sender && (
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                  <img
                    src={document.sender.avatar}
                    alt={document.sender.name}
                    className="w-7 h-7 rounded-full object-cover ring-1 ring-indigo-500/40"
                  />
                  <div>
                    <div className="text-xs font-semibold text-white">{document.sender.name}</div>
                    <div className="text-[10px] text-slate-400">{document.sender.role}</div>
                  </div>
                </div>
              )}
            </div>

            {document.tags && document.tags.length > 0 && (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Tags</span>
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {document.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-[11px]"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
