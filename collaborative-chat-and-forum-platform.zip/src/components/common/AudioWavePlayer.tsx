"use client";

import React, { useState, useRef, useEffect } from "react";
import { Play, Pause, Volume2, RotateCcw, Download } from "lucide-react";
import { formatDuration } from "@/lib/utils";

interface AudioWavePlayerProps {
  src: string;
  duration?: number | null;
  waveform?: number[] | null;
  fileName?: string | null;
  isCurrentUser?: boolean;
}

export function AudioWavePlayer({
  src,
  duration = 30,
  waveform,
  fileName,
  isCurrentUser = false,
}: AudioWavePlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(duration || 30);
  const [playbackRate, setPlaybackRate] = useState<1 | 1.5 | 2>(1);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Generate fallback waveform if none provided
  const defaultWaveform = [
    25, 45, 65, 80, 50, 70, 95, 60, 40, 75, 90, 65, 45, 85, 95, 60, 35, 70, 85,
    55, 30, 65, 80, 50, 40, 70, 85, 45,
  ];
  const peaks = waveform && waveform.length > 0 ? waveform : defaultWaveform;

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setTotalDuration(Math.round(audio.duration));
      }
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("loadedmetadata", handleLoadedMetadata);
    audio.addEventListener("ended", handleEnded);

    return () => {
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
      audio.removeEventListener("ended", handleEnded);
    };
  }, []);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((err) => {
          console.warn("Audio play blocked or unavailable, using simulation timer:", err);
          // Fallback simulation timer if audio element src is inaccessible in sandbox
          setIsPlaying(true);
          const interval = setInterval(() => {
            setCurrentTime((prev) => {
              if (prev >= totalDuration) {
                clearInterval(interval);
                setIsPlaying(false);
                return 0;
              }
              return prev + 0.5;
            });
          }, 500);
        });
    }
  };

  const handleSeek = (index: number) => {
    const targetTime = (index / peaks.length) * totalDuration;
    setCurrentTime(targetTime);
    if (audioRef.current) {
      audioRef.current.currentTime = targetTime;
    }
  };

  const cycleSpeed = () => {
    const nextRate = playbackRate === 1 ? 1.5 : playbackRate === 1.5 ? 2 : 1;
    setPlaybackRate(nextRate);
    if (audioRef.current) {
      audioRef.current.playbackRate = nextRate;
    }
  };

  const progressPercent = totalDuration > 0 ? (currentTime / totalDuration) * 100 : 0;

  return (
    <div
      className={`rounded-2xl p-3 sm:p-4 max-w-md w-full transition-all ${
        isCurrentUser
          ? "bg-indigo-950/70 border border-indigo-500/30 text-indigo-100 shadow-md shadow-indigo-950/40"
          : "bg-slate-900/90 border border-slate-700/60 text-slate-100 shadow-md shadow-black/30"
      }`}
    >
      <audio ref={audioRef} src={src} preload="metadata" />

      {/* Header Info */}
      <div className="flex items-center justify-between gap-2 mb-2.5 text-xs">
        <div className="flex items-center gap-1.5 font-medium truncate opacity-90">
          <Volume2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
          <span className="truncate">{fileName || "Voice Note"}</span>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={cycleSpeed}
            title="Change Playback Speed"
            className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-white/10 hover:bg-white/20 transition cursor-pointer text-indigo-300"
          >
            {playbackRate}x
          </button>
          <a
            href={src}
            download={fileName || "voice-note.webm"}
            title="Download Audio"
            className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white transition"
          >
            <Download className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* Play Controls & Waveform */}
      <div className="flex items-center gap-3">
        <button
          onClick={togglePlay}
          className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-95 shadow-md cursor-pointer ${
            isCurrentUser
              ? "bg-indigo-500 hover:bg-indigo-400 text-white shadow-indigo-600/30"
              : "bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/30 font-bold"
          }`}
          aria-label={isPlaying ? "Pause" : "Play"}
        >
          {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 ml-0.5 fill-current" />}
        </button>

        {/* Waveform Visualization Bars */}
        <div className="flex-1 flex items-center gap-0.5 h-9 py-1 px-1 bg-black/20 rounded-lg overflow-hidden relative cursor-pointer group">
          {peaks.map((peak, idx) => {
            const barProgress = (idx / peaks.length) * 100;
            const isPassed = barProgress <= progressPercent;
            const normalizedHeight = Math.max(15, Math.min(100, peak));

            return (
              <div
                key={idx}
                onClick={() => handleSeek(idx)}
                style={{ height: `${normalizedHeight}%` }}
                className={`flex-1 min-w-[2.5px] rounded-full transition-all duration-150 ${
                  isPassed
                    ? isCurrentUser
                      ? "bg-indigo-400 shadow-sm shadow-indigo-400/50"
                      : "bg-emerald-400 shadow-sm shadow-emerald-400/50"
                    : "bg-slate-600/60 hover:bg-slate-500"
                } ${isPlaying && isPassed ? "animate-pulse" : ""}`}
              />
            );
          })}
        </div>
      </div>

      {/* Time Display */}
      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mt-2 px-1">
        <span>{formatDuration(currentTime)}</span>
        <span>{formatDuration(totalDuration)}</span>
      </div>
    </div>
  );
}
