"use client";

import React, { useState, useRef, useEffect } from "react";
import { Mic, Square, Trash2, Send, Play, Pause, AlertCircle, Sparkles } from "lucide-react";
import { formatDuration } from "@/lib/utils";

interface VoiceRecorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendVoiceNote: (audioData: {
    dataUrl: string;
    duration: number;
    waveform: number[];
    fileName: string;
  }) => void;
}

export function VoiceRecorderModal({
  isOpen,
  onClose,
  onSendVoiceNote,
}: VoiceRecorderModalProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [waveformPeaks, setWaveformPeaks] = useState<number[]>([]);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [permissionError, setPermissionError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      // Reset state on open
      setIsRecording(false);
      setRecordingDuration(0);
      setAudioBlob(null);
      setAudioUrl(null);
      setWaveformPeaks([]);
      setPermissionError(null);
      setIsPlayingPreview(false);
    } else {
      stopAllMedia();
    }
  }, [isOpen]);

  const stopAllMedia = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
    }
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
    }
  };

  const startRecording = async () => {
    setPermissionError(null);
    setAudioBlob(null);
    setAudioUrl(null);
    setWaveformPeaks([]);
    audioChunksRef.current = [];

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Microphone API not supported on this browser.");
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const tracks = stream.getTracks();
        tracks.forEach((track) => track.stop());

        const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        setAudioBlob(blob);
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);

        // Generate waveform peaks
        generatePeaksFromBlob(blob);
      };

      mediaRecorder.start(200);
      setIsRecording(true);
      setRecordingDuration(0);

      timerIntervalRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.warn("Microphone access failed:", err);
      setPermissionError(
        "Microphone permission not granted or unavailable. You can use the Quick Voice Memo Generator below!"
      );
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
    }
    setIsRecording(false);
  };

  const generatePeaksFromBlob = async (blob: Blob) => {
    try {
      const arrayBuffer = await blob.arrayBuffer();
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtx();
      const decodedBuffer = await audioCtx.decodeAudioData(arrayBuffer);
      const rawData = decodedBuffer.getChannelData(0);
      const samples = 28;
      const blockSize = Math.floor(rawData.length / samples);
      const peaks: number[] = [];

      for (let i = 0; i < samples; i++) {
        let sum = 0;
        for (let j = 0; j < blockSize; j++) {
          sum += Math.abs(rawData[i * blockSize + j]);
        }
        const val = Math.min(100, Math.max(15, Math.round((sum / blockSize) * 350)));
        peaks.push(val);
      }
      setWaveformPeaks(peaks);
    } catch (e) {
      // Fallback synthetic random realistic peaks
      const synthPeaks = Array.from({ length: 28 }, () => Math.floor(Math.random() * 65) + 25);
      setWaveformPeaks(synthPeaks);
    }
  };

  // Quick memo simulation helper if mic blocked
  const useSampleVoiceMemo = (title: string, durationSec: number) => {
    const synthPeaks = [30, 55, 75, 90, 45, 65, 95, 80, 40, 60, 85, 70, 45, 80, 95, 65, 40, 65, 80, 55, 35, 65, 85, 90, 45, 70, 40, 25];
    const sampleOgg = "https://actions.google.com/sounds/v1/ambiences/coffee_shop.ogg";

    onSendVoiceNote({
      dataUrl: sampleOgg,
      duration: durationSec,
      waveform: synthPeaks,
      fileName: `Voice Memo: ${title} (${formatDuration(durationSec)})`,
    });
    onClose();
  };

  const handleSend = () => {
    if (!audioBlob) return;

    const reader = new FileReader();
    reader.readAsDataURL(audioBlob);
    reader.onloadend = () => {
      const base64data = reader.result as string;
      onSendVoiceNote({
        dataUrl: base64data,
        duration: Math.max(1, recordingDuration),
        waveform: waveformPeaks.length > 0 ? waveformPeaks : [30, 60, 80, 95, 50, 70, 85, 60, 40, 65, 90, 45],
        fileName: `Voice Note (${formatDuration(recordingDuration)})`,
      });
      onClose();
    };
  };

  const togglePreview = () => {
    if (!previewAudioRef.current) return;
    if (isPlayingPreview) {
      previewAudioRef.current.pause();
      setIsPlayingPreview(false);
    } else {
      previewAudioRef.current.play();
      setIsPlayingPreview(true);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-md p-6 shadow-2xl relative overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-indigo-500/20 rounded-full blur-2xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Record Voice Note</h3>
              <p className="text-xs text-slate-400">Share audio walkthroughs and instant voice messages</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            ✕
          </button>
        </div>

        {/* Permission warning if any */}
        {permissionError && (
          <div className="mb-4 p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-2 text-xs text-amber-200">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>{permissionError}</span>
          </div>
        )}

        {/* Recording Center Area */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center my-2 text-center relative">
          {/* Animated rings when recording */}
          {isRecording && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-28 h-28 rounded-full bg-rose-500/20 animate-ping opacity-50" />
              <div className="w-36 h-36 rounded-full bg-rose-500/10 animate-pulse" />
            </div>
          )}

          {/* Large Record Button */}
          {!audioUrl ? (
            <div>
              <button
                onClick={isRecording ? stopRecording : startRecording}
                className={`w-20 h-20 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-lg ${
                  isRecording
                    ? "bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/50 scale-105"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30 hover:scale-105 active:scale-95"
                }`}
              >
                {isRecording ? <Square className="w-8 h-8 fill-current" /> : <Mic className="w-8 h-8" />}
              </button>

              <div className="mt-4">
                <div className="text-2xl font-mono font-bold text-white">
                  {formatDuration(recordingDuration)}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {isRecording ? "Listening... click to stop" : "Click microphone to start recording"}
                </p>
              </div>
            </div>
          ) : (
            // Recorded Preview Section
            <div className="w-full flex flex-col items-center">
              <audio
                ref={previewAudioRef}
                src={audioUrl}
                onEnded={() => setIsPlayingPreview(false)}
              />
              <div className="flex items-center gap-3 w-full mb-3">
                <button
                  onClick={togglePreview}
                  className="w-12 h-12 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center shrink-0 cursor-pointer shadow-md font-bold"
                >
                  {isPlayingPreview ? (
                    <Pause className="w-5 h-5 fill-current" />
                  ) : (
                    <Play className="w-5 h-5 ml-0.5 fill-current" />
                  )}
                </button>

                {/* Waveform preview bars */}
                <div className="flex-1 flex items-center gap-0.5 h-10 px-2 bg-slate-900 rounded-lg">
                  {waveformPeaks.map((peak, idx) => (
                    <div
                      key={idx}
                      style={{ height: `${peak}%` }}
                      className="flex-1 bg-emerald-400/80 rounded-full min-w-[2px]"
                    />
                  ))}
                </div>
              </div>

              <div className="text-xs font-mono text-emerald-400 font-semibold">
                Recorded: {formatDuration(recordingDuration)}
              </div>
            </div>
          )}
        </div>

        {/* Quick Sample Voice Options for Demonstration */}
        <div className="mt-4 pt-4 border-t border-slate-800/80">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-400 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Sample Quick Voice Memos (1-click send):</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => useSampleVoiceMemo("Schema Architecture Walkthrough", 38)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-left text-xs text-slate-200 transition cursor-pointer flex flex-col"
            >
              <span className="font-medium text-indigo-300">🎙️ Tech Spec Sync</span>
              <span className="text-[10px] text-slate-400">Duration: 0:38</span>
            </button>
            <button
              onClick={() => useSampleVoiceMemo("UI Wireframe & Design Feedback", 24)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-left text-xs text-slate-200 transition cursor-pointer flex flex-col"
            >
              <span className="font-medium text-purple-300">🎨 Design Review</span>
              <span className="text-[10px] text-slate-400">Duration: 0:24</span>
            </button>
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            Cancel
          </button>

          {audioUrl && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setAudioUrl(null);
                  setAudioBlob(null);
                  setRecordingDuration(0);
                  setWaveformPeaks([]);
                }}
                className="px-3 py-2 rounded-xl text-xs font-medium text-rose-400 hover:bg-rose-500/10 border border-rose-500/20 transition flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Retake
              </button>
              <button
                onClick={handleSend}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30 transition flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                Send Voice Note
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
