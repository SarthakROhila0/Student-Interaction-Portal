"use client";

import React, { useState } from "react";
import { X, Download, ZoomIn, ZoomOut, RotateCw } from "lucide-react";
import { formatBytes } from "@/lib/utils";

interface ImageLightboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string | null;
  imageName?: string | null;
  imageSize?: number | null;
  caption?: string | null;
}

export function ImageLightboxModal({
  isOpen,
  onClose,
  imageUrl,
  imageName,
  imageSize,
  caption,
}: ImageLightboxModalProps) {
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);

  if (!isOpen || !imageUrl) return null;

  const handleZoomIn = () => setZoom((prev) => Math.min(prev + 0.25, 3));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev - 0.25, 0.5));
  const handleRotate = () => setRotation((prev) => (prev + 90) % 360);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
      {/* Top Controls Bar */}
      <div className="w-full max-w-5xl flex items-center justify-between py-3 px-4 bg-slate-900/80 border border-slate-800 rounded-t-2xl z-10">
        <div className="flex items-center gap-2 truncate">
          <span className="text-sm font-medium text-white truncate">{imageName || "Image Preview"}</span>
          {imageSize && (
            <span className="text-xs text-slate-400">({formatBytes(imageSize)})</span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleZoomOut}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-slate-400 w-12 text-center">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={handleZoomIn}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={handleRotate}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            title="Rotate"
          >
            <RotateCw className="w-4 h-4" />
          </button>
          <a
            href={imageUrl}
            download={imageName || "download.png"}
            className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition flex items-center gap-1 text-xs cursor-pointer"
            title="Download Image"
          >
            <Download className="w-4 h-4" />
          </a>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer ml-2"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Image Container with Zoom & Pan */}
      <div className="w-full max-w-5xl flex-1 bg-slate-950/90 border-x border-b border-slate-800 rounded-b-2xl overflow-auto flex items-center justify-center p-4 min-h-[350px]">
        <img
          src={imageUrl}
          alt={imageName || "Image preview"}
          style={{
            transform: `scale(${zoom}) rotate(${rotation}deg)`,
            transition: "transform 0.2s ease-out",
          }}
          className="max-h-[75vh] max-w-full object-contain rounded-lg shadow-2xl"
        />
      </div>

      {caption && (
        <div className="mt-3 text-xs text-slate-300 bg-slate-900/90 px-4 py-2 rounded-xl border border-slate-800 max-w-lg text-center">
          {caption}
        </div>
      )}
    </div>
  );
}
