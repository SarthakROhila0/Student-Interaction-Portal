"use client";

import React, { useState, useEffect } from "react";
import {
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Monitor,
  Volume2,
  Users,
} from "lucide-react";
import { User } from "@/types";
import { formatDuration } from "@/lib/utils";

interface CallSimulationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  partnerUser: User | null;
  isVideoCall?: boolean;
  onCallEnded?: (callDurationSec: number) => void;
}

export function CallSimulationModal({
  isOpen,
  onClose,
  currentUser,
  partnerUser,
  isVideoCall = false,
  onCallEnded,
}: CallSimulationModalProps) {
  const [callState, setCallState] = useState<"ringing" | "connected">("ringing");
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(isVideoCall);
  const [isScreenSharing, setIsScreenSharing] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setCallState("ringing");
      setCallDuration(0);
      setIsMuted(false);
      setIsScreenSharing(false);
      return;
    }

    // Simulate partner answering after 2 seconds
    const ringTimer = setTimeout(() => {
      setCallState("connected");
    }, 2200);

    return () => clearTimeout(ringTimer);
  }, [isOpen]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isOpen && callState === "connected") {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isOpen, callState]);

  const handleEndCall = () => {
    if (onCallEnded) {
      onCallEnded(callDuration);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col relative">
        {/* Top Status */}
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div
              className={`w-2.5 h-2.5 rounded-full ${
                callState === "connected" ? "bg-emerald-400 animate-pulse" : "bg-amber-400 animate-ping"
              }`}
            />
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              {callState === "ringing" ? "Calling Partner..." : "Encrypted 2-Way Connection"}
            </span>
          </div>

          <div className="text-xs font-mono font-bold text-indigo-400">
            {callState === "connected" ? formatDuration(callDuration) : "Ringing..."}
          </div>
        </div>

        {/* Video / Call Center Area */}
        <div className="relative h-80 sm:h-96 bg-gradient-to-b from-slate-950 to-slate-900 flex items-center justify-center p-6 overflow-hidden">
          {isVideoEnabled ? (
            <div className="relative w-full h-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center">
              {/* Main Partner Video Feed Simulation */}
              <img
                src={partnerUser?.avatar || "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=600&auto=format&fit=crop&q=80"}
                alt={partnerUser?.name || "Partner"}
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs text-white flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span>{partnerUser?.name} (HD 1080p)</span>
              </div>

              {/* Pip Self Feed Simulation */}
              <div className="absolute bottom-4 right-4 w-28 h-28 sm:w-36 sm:h-36 rounded-xl overflow-hidden border-2 border-indigo-500 shadow-xl bg-slate-900">
                <img
                  src={currentUser?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80"}
                  alt={currentUser?.name || "Self"}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-1 left-1 right-1 bg-black/70 text-[9px] text-center text-indigo-300 py-0.5 rounded">
                  You ({currentUser?.name})
                </div>
              </div>
            </div>
          ) : (
            // Audio Call Avatars
            <div className="flex flex-col items-center justify-center text-center z-10">
              <div className="relative mb-4">
                <div className="w-24 h-24 rounded-full overflow-hidden ring-4 ring-indigo-500/40 shadow-2xl">
                  <img
                    src={partnerUser?.avatar}
                    alt={partnerUser?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                {callState === "ringing" && (
                  <div className="absolute inset-0 rounded-full border-4 border-indigo-400 animate-ping opacity-60 pointer-events-none" />
                )}
              </div>

              <h3 className="text-xl font-bold text-white">{partnerUser?.name}</h3>
              <p className="text-xs text-slate-400 mt-0.5">{partnerUser?.role}</p>

              <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300">
                <Volume2 className="w-3.5 h-3.5" />
                <span>High-Definition Opus Audio Stream</span>
              </div>
            </div>
          )}

          {/* Screen sharing overlay simulation */}
          {isScreenSharing && (
            <div className="absolute top-4 right-4 bg-indigo-600/90 text-white text-[11px] font-medium px-3 py-1.5 rounded-xl shadow flex items-center gap-1.5 animate-pulse">
              <Monitor className="w-3.5 h-3.5" />
              <span>Screen Sharing Active</span>
            </div>
          )}
        </div>

        {/* Call Controls Bar */}
        <div className="p-5 bg-slate-950 border-t border-slate-800 flex items-center justify-center gap-3 sm:gap-4">
          <button
            onClick={() => setIsMuted((prev) => !prev)}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition cursor-pointer ${
              isMuted
                ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                : "bg-slate-800 hover:bg-slate-700 text-white"
            }`}
            title={isMuted ? "Unmute Mic" : "Mute Mic"}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <button
            onClick={() => setIsVideoEnabled((prev) => !prev)}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition cursor-pointer ${
              !isVideoEnabled
                ? "bg-slate-800 hover:bg-slate-700 text-slate-400"
                : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30 shadow-md"
            }`}
            title={isVideoEnabled ? "Turn off Video" : "Turn on Video"}
          >
            {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
          </button>

          <button
            onClick={() => setIsScreenSharing((prev) => !prev)}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition cursor-pointer ${
              isScreenSharing
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                : "bg-slate-800 hover:bg-slate-700 text-slate-400"
            }`}
            title={isScreenSharing ? "Stop Sharing Screen" : "Share Screen"}
          >
            <Monitor className="w-5 h-5" />
          </button>

          {/* End Call Button */}
          <button
            onClick={handleEndCall}
            className="w-14 h-12 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/40 transition active:scale-95 cursor-pointer ml-2"
            title="End Call"
          >
            <PhoneOff className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
}
