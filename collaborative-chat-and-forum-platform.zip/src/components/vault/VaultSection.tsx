"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  Folder,
  FileText,
  Image as ImageIcon,
  Mic,
  Code,
  Download,
  Eye,
  Plus,
  Search,
  Tag,
  Calendar,
  HardDrive,
  Trash2,
  Sparkles,
} from "lucide-react";
import { SharedFile, User } from "@/types";
import { useUser } from "@/context/UserContext";
import { formatBytes, formatTimeAgo, getFileCategoryIcon } from "@/lib/utils";
import { DocumentViewerModal } from "@/components/common/DocumentViewerModal";
import { ImageLightboxModal } from "@/components/common/ImageLightboxModal";

export function VaultSection() {
  const { currentUser } = useUser();
  const [files, setFiles] = useState<SharedFile[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Preview modals
  const [previewDoc, setPreviewDoc] = useState<any | null>(null);
  const [previewImg, setPreviewImg] = useState<any | null>(null);

  // New file upload modal states
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadCategory, setUploadCategory] = useState("document");
  const [uploadDesc, setUploadDesc] = useState("");
  const [uploadTags, setUploadTags] = useState("Spec, v2");
  const [uploadDataUrl, setUploadDataUrl] = useState<string | null>(null);
  const [uploadFileName, setUploadFileName] = useState("");
  const [uploadFileSize, setUploadFileSize] = useState(0);
  const [uploadMime, setUploadMime] = useState("");

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const fetchFiles = async () => {
    try {
      let url = "/api/files";
      const params = new URLSearchParams();
      if (activeCategory !== "all") params.append("category", activeCategory);
      if (searchQuery) params.append("query", searchQuery);
      if (params.toString()) url += `?${params.toString()}`;

      const res = await fetch(url);
      const data = await res.json();
      if (data.success && Array.isArray(data.files)) {
        setFiles(data.files);
      }
    } catch (err) {
      console.error("Failed to load vault files:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFiles();
  }, [activeCategory, searchQuery]);

  const handleFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fls = e.target.files;
    if (!fls || fls.length === 0) return;
    const f = fls[0];

    setUploadFileName(f.name);
    setUploadFileSize(f.size);
    setUploadMime(f.type || "application/octet-stream");
    if (!uploadTitle) setUploadTitle(f.name);

    if (f.type.startsWith("image/")) setUploadCategory("image");
    else if (f.type.startsWith("audio/")) setUploadCategory("voice");
    else if (f.name.endsWith(".ts") || f.name.endsWith(".js") || f.name.endsWith(".json"))
      setUploadCategory("code");
    else setUploadCategory("document");

    const reader = new FileReader();
    reader.onload = () => {
      setUploadDataUrl(reader.result as string);
    };
    reader.readAsDataURL(f);
  };

  const handleCreateVaultFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !uploadDataUrl) return;

    try {
      const parsedTags = uploadTags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean);

      const res = await fetch("/api/files", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          senderId: currentUser.id,
          fileName: uploadTitle || uploadFileName,
          fileUrl: uploadDataUrl,
          fileSize: uploadFileSize || 1024 * 50,
          mimeType: uploadMime || "application/octet-stream",
          category: uploadCategory,
          description: uploadDesc,
          tags: parsedTags,
        }),
      });

      const data = await res.json();
      if (data.success && data.file) {
        setFiles((prev) => [data.file, ...prev]);
        setShowUploadModal(false);
        // Reset modal
        setUploadTitle("");
        setUploadDesc("");
        setUploadDataUrl(null);
        setUploadFileName("");
      }
    } catch (err) {
      console.error("Vault upload failed:", err);
    }
  };

  const handleDownload = async (file: SharedFile) => {
    try {
      await fetch(`/api/files/${file.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "increment_download" }),
      });
      setFiles((prev) =>
        prev.map((f) => (f.id === file.id ? { ...f, downloadsCount: f.downloadsCount + 1 } : f))
      );
    } catch (err) {
      console.error("Download increment error:", err);
    }
  };

  const handleDeleteFile = async (fileId: number) => {
    try {
      setFiles((prev) => prev.filter((f) => f.id !== fileId));
      await fetch(`/api/files/${fileId}`, { method: "DELETE" });
    } catch (err) {
      console.error("Delete file error:", err);
    }
  };

  const categories = [
    { id: "all", label: "All Assets", icon: Folder },
    { id: "document", label: "Documents", icon: FileText },
    { id: "image", label: "Images", icon: ImageIcon },
    { id: "voice", label: "Voice Notes", icon: Mic },
    { id: "code", label: "Code & Specs", icon: Code },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner & Action Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-md relative overflow-hidden shadow-xl">
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-xs font-semibold text-indigo-400 mb-2">
              <Folder className="w-3.5 h-3.5" />
              <span>Unified Media & Document Vault</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Shared Media & Document Repository
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Centralized storage for all PDF specifications, architectural blueprints, voice walkthroughs, and code assets exchanged between collaborators.
            </p>
          </div>

          <button
            onClick={() => setShowUploadModal(true)}
            className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition cursor-pointer self-start sm:self-auto shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Upload New Asset</span>
          </button>
        </div>

        {/* Filter Tabs & Search Controls */}
        <div className="mt-8 flex flex-col md:flex-row items-center justify-between gap-4 pt-6 border-t border-slate-800/80">
          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-medium flex items-center gap-2 transition cursor-pointer shrink-0 ${
                    isActive
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                      : "bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/50"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search assets or tags..."
              className="w-full bg-slate-950/80 border border-slate-800 rounded-xl py-2 pl-9 pr-4 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Files Grid */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center p-12 text-slate-400">
          <Sparkles className="w-6 h-6 animate-spin text-indigo-400 mb-2" />
          <span className="text-xs">Loading vault repository...</span>
        </div>
      ) : files.length === 0 ? (
        <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-12 text-center text-slate-400">
          <Folder className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-300">No assets in this category</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Upload a document, share an image in chat, or record a voice note to populate the vault!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {files.map((file) => {
            const isImage = file.category === "image" || file.mimeType?.startsWith("image/");
            const isVoice = file.category === "voice" || file.mimeType?.startsWith("audio/");

            return (
              <div
                key={file.id}
                className="bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 rounded-2xl p-5 flex flex-col justify-between transition shadow-md hover:shadow-xl group relative overflow-hidden"
              >
                <div>
                  {/* Top Thumbnail & Category Badge */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-2xl shrink-0">
                      {getFileCategoryIcon(file.category, file.mimeType)}
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                      {file.category}
                    </span>
                  </div>

                  {/* Image Preview Thumbnail if image */}
                  {isImage && (
                    <div
                      onClick={() =>
                        setPreviewImg({
                          imageUrl: file.fileUrl,
                          imageName: file.fileName,
                          imageSize: file.fileSize,
                          caption: file.description,
                        })
                      }
                      className="mb-3 rounded-xl overflow-hidden h-36 bg-slate-950 border border-slate-800 cursor-pointer relative group/thumb"
                    >
                      <img
                        src={file.fileUrl}
                        alt={file.fileName}
                        className="w-full h-full object-cover group-hover/thumb:scale-105 transition-transform"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/thumb:opacity-100 transition-opacity flex items-center justify-center gap-1.5 text-white text-xs font-semibold">
                        <Eye className="w-4 h-4" />
                        <span>Inspect</span>
                      </div>
                    </div>
                  )}

                  {/* File Name & Description */}
                  <h3 className="font-bold text-sm text-white truncate" title={file.fileName}>
                    {file.fileName}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {file.description || "Shared project asset in collaboration workspace."}
                  </p>

                  {/* Tags */}
                  {file.tags && file.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-3">
                      {file.tags.map((tag, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px]"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Bottom Metadata & Actions */}
                <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-2">
                    {file.sender && (
                      <img
                        src={file.sender.avatar}
                        alt={file.sender.name}
                        className="w-5 h-5 rounded-full object-cover ring-1 ring-slate-700"
                        title={`Uploaded by ${file.sender.name}`}
                      />
                    )}
                    <span className="font-mono text-[11px]">{formatBytes(file.fileSize)}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Preview Button */}
                    <button
                      onClick={() => {
                        if (isImage) {
                          setPreviewImg({
                            imageUrl: file.fileUrl,
                            imageName: file.fileName,
                            imageSize: file.fileSize,
                            caption: file.description,
                          });
                        } else {
                          setPreviewDoc({
                            fileName: file.fileName,
                            fileUrl: file.fileUrl,
                            fileSize: file.fileSize,
                            mimeType: file.mimeType,
                            description: file.description,
                            sender: file.sender,
                            tags: file.tags,
                            createdAt: file.createdAt,
                          });
                        }
                      }}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                      title="Preview"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>

                    {/* Download Button */}
                    <a
                      href={file.fileUrl}
                      download={file.fileName}
                      onClick={() => handleDownload(file)}
                      className="p-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition cursor-pointer flex items-center gap-1 text-[11px] px-2"
                      title="Download File"
                    >
                      <Download className="w-3.5 h-3.5" />
                      {file.downloadsCount > 0 && <span>{file.downloadsCount}</span>}
                    </a>

                    {currentUser && currentUser.id === file.senderId && (
                      <button
                        onClick={() => handleDeleteFile(file.id)}
                        className="p-1.5 rounded-lg hover:bg-rose-500/20 text-slate-500 hover:text-rose-400 transition cursor-pointer"
                        title="Delete from Vault"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Upload File Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-lg p-6 shadow-2xl relative">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-white">Upload Asset to Vault</h3>
              <button
                onClick={() => setShowUploadModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateVaultFile} className="space-y-4">
              {/* File Dropzone */}
              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  onChange={handleFilePicked}
                  className="hidden"
                />
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-700 hover:border-indigo-500 rounded-2xl p-6 text-center cursor-pointer bg-slate-950/60 hover:bg-slate-950 transition"
                >
                  {uploadFileName ? (
                    <div>
                      <div className="text-2xl mb-1">
                        {getFileCategoryIcon(uploadCategory, uploadMime)}
                      </div>
                      <div className="text-sm font-semibold text-white truncate max-w-xs mx-auto">
                        {uploadFileName}
                      </div>
                      <div className="text-xs text-slate-400 font-mono mt-0.5">
                        {formatBytes(uploadFileSize)} • {uploadMime}
                      </div>
                    </div>
                  ) : (
                    <div>
                      <Folder className="w-8 h-8 text-indigo-400 mx-auto mb-2" />
                      <p className="text-xs font-semibold text-white">
                        Click to select document, image, or audio
                      </p>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Supports PDF, PNG, JPG, MP3, WebM, JSON, TS, etc.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Asset Title
                </label>
                <input
                  type="text"
                  required
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  placeholder="e.g. Architecture Spec v2.4"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Category */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Category
                  </label>
                  <select
                    value={uploadCategory}
                    onChange={(e) => setUploadCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="document">📄 Document</option>
                    <option value="image">🖼️ Image</option>
                    <option value="voice">🎤 Voice Memo</option>
                    <option value="code">💻 Code / Schema</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Tags (comma separated)
                  </label>
                  <input
                    type="text"
                    value={uploadTags}
                    onChange={(e) => setUploadTags(e.target.value)}
                    placeholder="v2, Postgres, UI"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Description / Notes
                </label>
                <textarea
                  rows={2}
                  value={uploadDesc}
                  onChange={(e) => setUploadDesc(e.target.value)}
                  placeholder="Brief note on what this asset contains..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500 resize-none"
                />
              </div>

              {/* Submit */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!uploadDataUrl || !uploadTitle}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition cursor-pointer"
                >
                  Save Asset to Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Document Viewer Modal */}
      <DocumentViewerModal
        isOpen={!!previewDoc}
        onClose={() => setPreviewDoc(null)}
        document={previewDoc}
      />

      {/* Image Lightbox Modal */}
      <ImageLightboxModal
        isOpen={!!previewImg}
        onClose={() => setPreviewImg(null)}
        imageUrl={previewImg?.imageUrl || null}
        imageName={previewImg?.imageName || null}
        imageSize={previewImg?.imageSize || null}
        caption={previewImg?.caption || null}
      />
    </div>
  );
}
