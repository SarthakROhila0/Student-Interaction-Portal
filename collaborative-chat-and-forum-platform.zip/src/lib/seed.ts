import { db } from "@/db";
import {
  users,
  conversations,
  messages,
  sharedFiles,
  qnaQuestions,
  qnaAnswers,
  qnaVotes,
  forums,
  forumThreads,
  forumReplies,
  collaborationNotes,
} from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function ensureDatabaseSeeded() {
  try {
    const existingUsers = await db.select().from(users);
    if (existingUsers.length > 0) {
      return;
    }

    console.log("Seeding database with default portal data...");

    // 1. Seed Users
    const defaultUsers = [
      {
        id: "user_alex",
        name: "Alex Rivera",
        email: "alex.rivera@portal.dev",
        avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80",
        role: "Principal Systems Architect",
        department: "Core Engineering",
        status: "online",
        statusMessage: "Optimizing database schemas & distributed sync",
        bio: "Fullstack & distributed systems engineer. Love high-concurrency architectures, Postgres performance tuning, and clean UI engineering.",
        reputation: 640,
      },
      {
        id: "user_elena",
        name: "Elena Chen",
        email: "elena.chen@portal.dev",
        avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80",
        role: "Lead Product Designer & UX",
        department: "Product Design",
        status: "online",
        statusMessage: "Reviewing dual-pane interaction flows & Q&A layouts",
        bio: "Leading product experience and UX systems. Obsessed with micro-interactions, responsive accessibility, and user-centric design.",
        reputation: 710,
      },
      {
        id: "user_marcus",
        name: "Marcus Vance",
        email: "marcus.vance@portal.dev",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
        role: "DevOps & Cloud Lead",
        department: "Infrastructure",
        status: "away",
        statusMessage: "Monitoring deployment pipeline health",
        bio: "Cloud infrastructure architect and observability enthusiast. Automating workflows and maintaining 99.99% uptime.",
        reputation: 390,
      },
    ];

    await db.insert(users).values(defaultUsers);

    // 2. Seed Direct Conversation between Alex & Elena
    const convId = "conv_alex_elena";
    await db.insert(conversations).values([
      {
        id: convId,
        title: "Alex & Elena Direct Collab",
        type: "direct",
        user1Id: "user_alex",
        user2Id: "user_elena",
        description: "Primary 2-way collaboration and direct media exchange",
        isPinned: true,
        lastMessageText: "Checked the new responsive wireframe - looks super crisp! Let's ship it.",
        lastMessageAt: new Date(Date.now() - 2 * 60 * 1000),
      },
      {
        id: "conv_alex_marcus",
        title: "Alex & Marcus (Infra Sync)",
        type: "direct",
        user1Id: "user_alex",
        user2Id: "user_marcus",
        description: "Infrastructure and database indexing coordination",
        isPinned: false,
        lastMessageText: "DB indices have been updated in staging environment.",
        lastMessageAt: new Date(Date.now() - 45 * 60 * 1000),
      },
    ]);

    // 3. Seed Rich Messages (Text, Document, Image, Voice Note)
    const seedMessages = [
      {
        conversationId: convId,
        senderId: "user_elena",
        receiverId: "user_alex",
        content: "Hey Alex! 👋 I just finalized the system architecture diagram and the v2 UI layout tokens for our new dual-user portal.",
        type: "text",
        createdAt: new Date(Date.now() - 35 * 60 * 1000),
      },
      {
        conversationId: convId,
        senderId: "user_elena",
        receiverId: "user_alex",
        content: "Here is the visual blueprint for the split interaction views and file previews:",
        type: "image",
        mediaUrl: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=1000&auto=format&fit=crop&q=80",
        mediaName: "portal-design-system-v2.png",
        mediaSize: 1845000,
        mediaMime: "image/png",
        reactions: JSON.stringify({ "🔥": ["user_alex"], "❤️": ["user_elena"] }),
        createdAt: new Date(Date.now() - 32 * 60 * 1000),
      },
      {
        conversationId: convId,
        senderId: "user_alex",
        receiverId: "user_elena",
        content: "This looks fantastic! The contrast and component spacing are spot on. I also wrote up the functional requirements and real-time schema specification document.",
        type: "text",
        createdAt: new Date(Date.now() - 25 * 60 * 1000),
      },
      {
        conversationId: convId,
        senderId: "user_alex",
        receiverId: "user_elena",
        content: "Full technical specification including PostgreSQL schema, media storage structure, and Q&A indexing:",
        type: "document",
        mediaUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
        mediaName: "System-Architecture-Spec-v2.4.pdf",
        mediaSize: 3420000,
        mediaMime: "application/pdf",
        reactions: JSON.stringify({ "🚀": ["user_elena"], "👍": ["user_alex"] }),
        createdAt: new Date(Date.now() - 20 * 60 * 1000),
      },
      {
        conversationId: convId,
        senderId: "user_elena",
        receiverId: "user_alex",
        content: "Recorded a quick voice walkthrough on the Q&A acceptance flow and voice player UX:",
        type: "voice",
        mediaUrl: "https://actions.google.com/sounds/v1/ambiences/coffee_shop.ogg",
        mediaName: "Voice Note: UX Flow Walkthrough (0:38)",
        mediaSize: 412000,
        mediaMime: "audio/ogg",
        mediaDuration: 38,
        mediaWaveform: JSON.stringify([24, 45, 68, 85, 40, 60, 92, 75, 30, 55, 88, 65, 42, 80, 95, 70, 48, 62, 78, 50, 32, 60, 84, 90, 45, 70, 35, 20]),
        reactions: JSON.stringify({ "💡": ["user_alex"] }),
        createdAt: new Date(Date.now() - 12 * 60 * 1000),
      },
      {
        conversationId: convId,
        senderId: "user_alex",
        receiverId: "user_elena",
        content: "Audio note received! I loved the idea of instant verified badges when the question author accepts an answer. I've committed the schema update.",
        type: "text",
        reactions: JSON.stringify({ "🙌": ["user_elena"] }),
        createdAt: new Date(Date.now() - 5 * 60 * 1000),
      },
      {
        conversationId: convId,
        senderId: "user_elena",
        receiverId: "user_alex",
        content: "Checked the new responsive wireframe - looks super crisp! Let's ship it.",
        type: "text",
        createdAt: new Date(Date.now() - 2 * 60 * 1000),
      },
    ];

    await db.insert(messages).values(seedMessages);

    // 4. Seed Shared Files in Vault
    await db.insert(sharedFiles).values([
      {
        senderId: "user_alex",
        conversationId: convId,
        category: "document",
        fileName: "System-Architecture-Spec-v2.4.pdf",
        fileUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
        fileSize: 3420000,
        mimeType: "application/pdf",
        description: "Comprehensive backend architecture, Drizzle tables, and WebSocket sync contracts.",
        tags: JSON.stringify(["Architecture", "Postgres", "Drizzle", "v2.4"]),
        downloadsCount: 14,
        createdAt: new Date(Date.now() - 20 * 60 * 1000),
      },
      {
        senderId: "user_elena",
        conversationId: convId,
        category: "image",
        fileName: "portal-design-system-v2.png",
        fileUrl: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=1000&auto=format&fit=crop&q=80",
        fileSize: 1845000,
        mimeType: "image/png",
        description: "High fidelity UI mockups for Chat, Document Vault, Q&A, and Forums.",
        tags: JSON.stringify(["Figma", "UI/UX", "Design System", "Components"]),
        downloadsCount: 22,
        createdAt: new Date(Date.now() - 32 * 60 * 1000),
      },
      {
        senderId: "user_elena",
        conversationId: convId,
        category: "voice",
        fileName: "Voice-UX-Walkthrough.ogg",
        fileUrl: "https://actions.google.com/sounds/v1/ambiences/coffee_shop.ogg",
        fileSize: 412000,
        mimeType: "audio/ogg",
        description: "Voice memo explaining the acceptance badge interaction and confetti feedback.",
        tags: JSON.stringify(["Voice Memo", "Feedback", "Q&A Flow"]),
        downloadsCount: 9,
        createdAt: new Date(Date.now() - 12 * 60 * 1000),
      },
      {
        senderId: "user_alex",
        conversationId: convId,
        category: "document",
        fileName: "Postgres-Index-Optimization-Guide.md",
        fileUrl: "https://raw.githubusercontent.com/github/explore/main/topics/postgresql/postgresql.png",
        fileSize: 154000,
        mimeType: "text/markdown",
        description: "Tips on composite indexing, GIN search vectors, and connection pool sizing.",
        tags: JSON.stringify(["Database", "SQL", "Optimization", "Performance"]),
        downloadsCount: 31,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        senderId: "user_elena",
        conversationId: convId,
        category: "image",
        fileName: "Mobile-Responsive-Breakpoints.png",
        fileUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1000&auto=format&fit=crop&q=80",
        fileSize: 2240000,
        mimeType: "image/png",
        description: "Grid layout blueprints across desktop, tablet, and mobile split screens.",
        tags: JSON.stringify(["Responsive", "CSS Grid", "Breakpoints"]),
        downloadsCount: 18,
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
    ]);

    // 5. Seed Q&A Section
    const q1 = await db
      .insert(qnaQuestions)
      .values({
        authorId: "user_elena",
        title: "How should we handle optimistic UI updates with Voice Note uploads and waveform generation?",
        content: `When a user records a voice memo using the Web Audio API or uploads an audio file, what is the best strategy to immediately show the waveform visualization in the chat stream before the full server upload completes?

Currently, we extract the Float32Array PCM buffer in the browser and want to serialize peak buckets (e.g. 30 samples) alongside the blob upload. Should we store the waveform peaks directly in the message record?`,
        category: "Architecture",
        tags: JSON.stringify(["WebAudio", "OptimisticUI", "VoiceNotes", "NextJS"]),
        viewsCount: 48,
        upvotesCount: 12,
        isSolved: true,
        acceptedAnswerId: 1,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      })
      .returning();

    const a1 = await db
      .insert(qnaAnswers)
      .values({
        questionId: q1[0].id,
        authorId: "user_alex",
        content: `Yes! Computing the waveform peaks client-side in an \`AudioContext\` or \`OfflineAudioContext\` during or right after recording is the cleanest approach.

Here is why:
1. **Zero Server CPU Overhead**: The browser does the fast FFT / peak extraction in ~5ms.
2. **Instant Optimistic Rendering**: You can pass \`mediaWaveform: [30, 65, 80, ...]\` directly in the optimistic message state.
3. **Database Efficiency**: Storing 20-40 integer amplitude points in a JSON column takes less than 150 bytes in Postgres.

Here is a quick snippet:
\`\`\`typescript
const rawData = audioBuffer.getChannelData(0);
const blockSize = Math.floor(rawData.length / 32);
const peaks = [];
for (let i = 0; i < 32; i++) {
  let sum = 0;
  for (let j = 0; j < blockSize; j++) {
    sum += Math.abs(rawData[i * blockSize + j]);
  }
  peaks.push(Math.round((sum / blockSize) * 100));
}
\`\`\`
This gives an ultra-smooth waveform animation on both sender and receiver views!`,
        upvotesCount: 15,
        isAccepted: true,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000 + 40 * 60 * 1000),
        updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000 + 40 * 60 * 1000),
      })
      .returning();

    // Update question acceptedAnswerId with actual answer ID
    await db
      .update(qnaQuestions)
      .set({ acceptedAnswerId: a1[0].id })
      .where(eq(qnaQuestions.id, q1[0].id));

    // Question 2
    const q2 = await db
      .insert(qnaQuestions)
      .values({
        authorId: "user_alex",
        title: "Best UX patterns for dual-user split screen testing vs single persona switcher?",
        content: `We want our platform testers and admins to experience the 2-user real-time interaction smoothly. Should we provide:
1. A top header **Persona Toggle** (Switch between Alex Rivera and Elena Chen in 1 click).
2. A **Dual-Screen Split View** where left side is Alex and right side is Elena simultaneously.
3. A synchronized polling/event bus mechanism.

What are the best layout conventions for this?`,
        category: "UI/UX",
        tags: JSON.stringify(["SplitView", "UXPattern", "DualUser", "PersonaToggle"]),
        viewsCount: 35,
        upvotesCount: 8,
        isSolved: false,
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      })
      .returning();

    await db.insert(qnaAnswers).values({
      questionId: q2[0].id,
      authorId: "user_elena",
      content: `I strongly recommend offering **BOTH**!
- **Persona Toggle in Top Header**: Perfect when using smaller screens or deep diving into a single user's workflow (e.g. Elena posting a Q&A question).
- **Dual-Pane Simulator Mode**: An absolute delight for presentations and real-time testing. You can type as Alex on the left, press Enter, and instantly see Elena receive it on the right side.

We should also add an active user badge with color coding (Alex: Indigo/Blue, Elena: Emerald/Purple) so it is instantly clear who is taking which action.`,
      upvotesCount: 9,
      isAccepted: false,
      createdAt: new Date(Date.now() - 20 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 20 * 60 * 60 * 1000),
    });

    // 6. Seed Community Forums
    const forum1 = await db
      .insert(forums)
      .values({
        slug: "engineering-architecture",
        title: "Engineering & Architecture",
        description: "Technical discussions, system design, PostgreSQL optimizations, and API contracts.",
        icon: "code",
        color: "indigo",
        createdById: "user_alex",
        threadsCount: 2,
      })
      .returning();

    const forum2 = await db
      .insert(forums)
      .values({
        slug: "product-design-ux",
        title: "Product Design & UX Lab",
        description: "User experience exploration, micro-interactions, accessibility standards, and component libraries.",
        icon: "sparkles",
        color: "purple",
        createdById: "user_elena",
        threadsCount: 2,
      })
      .returning();

    const forum3 = await db
      .insert(forums)
      .values({
        slug: "ideas-brainstorming",
        title: "Ideas & Brainstorming Vault",
        description: "Collaborative brainstorms, user feedback polls, and upcoming feature roadmap proposals.",
        icon: "lightbulb",
        color: "amber",
        createdById: "user_alex",
        threadsCount: 1,
      })
      .returning();

    const forum4 = await db
      .insert(forums)
      .values({
        slug: "general-watercooler",
        title: "General & Watercooler",
        description: "Casual chats, team shoutouts, tech news, and interesting links.",
        icon: "coffee",
        color: "emerald",
        createdById: "user_marcus",
        threadsCount: 1,
      })
      .returning();

    // Forum Threads
    const t1 = await db
      .insert(forumThreads)
      .values({
        forumId: forum1[0].id,
        authorId: "user_alex",
        title: "RFC: Real-time Multi-Media Collaboration Protocol for Next.js App Router",
        content: `Hey everyone! We've been designing our Next.js + PostgreSQL data syncing engine.

### Key Pillars:
1. **High Speed Polling & Mutation Sync**: Keeping client states synchronized with sub-second responsiveness without complex external broker dependencies.
2. **Unified Media Storage**: Supporting direct binary/data URLs for Voice Notes, PDF Specs, and High-Resolution Diagrams.
3. **Structured Q&A & Threaded Forums**: Combining real-time direct chat with persistent knowledge preservation.

Let's discuss thoughts on keeping the database query latency under 15ms.`,
        tags: JSON.stringify(["RFC", "Architecture", "NextJS", "PostgreSQL", "RealTime"]),
        isPinned: true,
        viewsCount: 112,
        likesCount: 18,
        repliesCount: 2,
        hasPoll: true,
        pollData: JSON.stringify({
          question: "Which database indexing strategy do you prioritize for chat & Q&A?",
          options: [
            { id: 1, text: "Composite (conversation_id, created_at DESC)", votes: ["user_alex", "user_elena"] },
            { id: 2, text: "Full text GIN search vectors on content & tags", votes: ["user_marcus"] },
            { id: 3, text: "Partial indices on is_solved / is_pinned", votes: [] },
          ],
        }),
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      })
      .returning();

    await db.insert(forumReplies).values([
      {
        threadId: t1[0].id,
        authorId: "user_elena",
        content: "Love this RFC! From a UX standpoint, having immediate optimistic updates while the message is in-flight makes the app feel native and responsive. Great work on the schema!",
        likesCount: 4,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        threadId: t1[0].id,
        authorId: "user_marcus",
        content: "I voted for composite indices! For message pagination (last 50 items), index scans are blazing fast (under 2ms).",
        likesCount: 3,
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
    ]);

    const t2 = await db
      .insert(forumThreads)
      .values({
        forumId: forum2[0].id,
        authorId: "user_elena",
        title: "Modern Audio Waveform & Voice Note Player Design Patterns",
        content: `We've designed a modern audio waveform player component for our direct 2-user chat.

### Features included:
- Dynamic animated SVG frequency bars
- Interactive seek bar with scrubbing
- Speed toggle (1.0x, 1.5x, 2.0x)
- Active recording timer with pulse indicator
- Download and preview options

Check it out and let me know your thoughts on the dark mode visual accents!`,
        tags: JSON.stringify(["Design", "VoiceNotes", "AudioPlayer", "TailwindCSS"]),
        isPinned: false,
        viewsCount: 84,
        likesCount: 14,
        repliesCount: 1,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      })
      .returning();

    await db.insert(forumReplies).values([
      {
        threadId: t2[0].id,
        authorId: "user_alex",
        content: "The dynamic speed toggle (1x / 1.5x / 2x) is such a nice touch! Makes reviewing long technical voice memos so much faster.",
        likesCount: 5,
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
    ]);

    // 7. Seed Collaboration Scratchpad Note
    await db.insert(collaborationNotes).values({
      title: "Sprint Collaboration & Shared Scratchpad",
      content: `## 🚀 Sprint Goals & Quick References

- [x] Direct 2-user real-time interaction engine
- [x] Document upload with download & preview cards
- [x] Image gallery with zoom & metadata
- [x] Real voice note recorder & animated waveform audio player
- [x] Structured Q&A knowledge base with accepted answers & upvoting
- [x] Custom forum creator & community discussions with polls
- [x] Split-screen dual user simulation mode

### Useful API Endpoints:
- \`/api/chat/messages\` - Send and fetch direct messages
- \`/api/chat/upload\` - Media and document handler
- \`/api/qna\` - Questions, answers, vote triggers
- \`/api/forums\` - Create forums, create threads, vote on polls

*Tip: Switch persona at any time using the top navigation pill!*`,
      updatedById: "user_alex",
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 30 * 60 * 1000),
    });

    console.log("Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}
