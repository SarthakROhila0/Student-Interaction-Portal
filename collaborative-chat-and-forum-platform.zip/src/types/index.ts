export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: string;
  department: string;
  status: "online" | "busy" | "away" | "offline";
  statusMessage?: string;
  bio?: string;
  reputation?: number;
  createdAt?: string;
}

export interface Message {
  id: number;
  conversationId: string;
  senderId: string;
  receiverId: string;
  content: string;
  type: "text" | "image" | "document" | "voice" | "code" | "call_log" | "interactive_poll";
  mediaUrl?: string | null;
  mediaName?: string | null;
  mediaSize?: number | null;
  mediaMime?: string | null;
  mediaDuration?: number | null;
  mediaWaveform?: number[] | null;
  replyToId?: number | null;
  isEdited?: boolean;
  isPinned?: boolean;
  reactions?: Record<string, string[]>;
  readAt?: string | null;
  createdAt: string;
  sender?: User | null;
  receiver?: User | null;
}

export interface Conversation {
  id: string;
  title: string;
  type: "direct" | "room" | "project";
  user1Id: string;
  user2Id: string;
  description?: string;
  isPinned?: boolean;
  lastMessageText?: string;
  lastMessageAt: string;
  createdAt?: string;
  user1?: User | null;
  user2?: User | null;
}

export interface SharedFile {
  id: number;
  senderId: string;
  conversationId?: string | null;
  category: "document" | "image" | "voice" | "code" | "other";
  fileName: string;
  fileUrl: string;
  fileSize: number;
  mimeType: string;
  description?: string;
  tags?: string[];
  downloadsCount: number;
  createdAt: string;
  sender?: User | null;
}

export interface QnaQuestion {
  id: number;
  authorId: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  viewsCount: number;
  upvotesCount: number;
  isSolved: boolean;
  acceptedAnswerId?: number | null;
  attachments?: any[];
  createdAt: string;
  updatedAt: string;
  author?: User | null;
  answersCount?: number;
  answers?: QnaAnswer[];
}

export interface QnaAnswer {
  id: number;
  questionId: number;
  authorId: string;
  content: string;
  upvotesCount: number;
  isAccepted: boolean;
  attachments?: any[];
  createdAt: string;
  updatedAt: string;
  author?: User | null;
}

export interface ForumCategory {
  id: number;
  slug: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  createdById: string;
  threadsCount: number;
  isPrivate: boolean;
  createdAt: string;
  createdBy?: User | null;
}

export interface ForumThread {
  id: number;
  forumId: number;
  authorId: string;
  title: string;
  content: string;
  tags: string[];
  isPinned: boolean;
  isLocked: boolean;
  viewsCount: number;
  likesCount: number;
  repliesCount: number;
  hasPoll: boolean;
  pollData?: {
    question: string;
    options: { id: number; text: string; votes: string[] }[];
  } | null;
  attachments?: any[];
  lastActivityAt: string;
  createdAt: string;
  author?: User | null;
  forum?: ForumCategory | null;
  replies?: ForumReply[];
}

export interface ForumReply {
  id: number;
  threadId: number;
  authorId: string;
  replyToId?: number | null;
  content: string;
  likesCount: number;
  attachments?: any[];
  createdAt: string;
  author?: User | null;
}

export interface CollaborationNote {
  id: number;
  title: string;
  content: string;
  updatedById: string;
  createdAt: string;
  updatedAt: string;
  updatedBy?: User | null;
}
